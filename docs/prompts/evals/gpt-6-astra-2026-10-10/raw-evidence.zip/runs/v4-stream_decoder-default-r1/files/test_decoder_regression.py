import unittest

from decoder import Decoder


def event(data, kind="message", ident=""):
    return {"event": kind, "data": data, "id": ident}


class DecoderRegression(unittest.TestCase):
    def assert_stream(self, text, expected):
        raw = text.encode("utf-8")
        # Include cuts within UTF-8 characters, the BOM, and CRLF pairs.
        chunks_to_try = [[raw], [bytes([byte]) for byte in raw]]
        chunks_to_try.extend([raw[:cut], raw[cut:]] for cut in range(len(raw) + 1))
        for chunks in chunks_to_try:
            with self.subTest(chunks=chunks):
                decoder = Decoder()
                actual = []
                for chunk in chunks:
                    actual.extend(decoder.feed(chunk))
                actual.extend(decoder.finish())
                self.assertEqual(actual, expected)
                self.assertEqual(decoder.finish(), [])

    def test_unicode_and_mixed_line_endings(self):
        self.assert_stream(
            "\ufeffdata: 中文🙂\r\ndata: 第二行\r\n\r\n"
            "data: LF\n\ndata: CR\r\rdata: mixed\r\n\rdata: tail",
            [event("中文🙂\n第二行"), event("LF"), event("CR"),
             event("mixed"), event("tail")],
        )

    def test_cr_dispatches_immediately_and_cross_chunk_lf_is_swallowed(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: one\r"), [])
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\n\r"), [event("one")])
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\ndata: two\r\r"), [event("two")])
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(decoder.finish(), [])

    def test_fields_preserve_whitespace_and_split_first_colon(self):
        self.assert_stream(
            ":data: ignored\nunknown: ignored\n data: ignored\n"
            "data:  leading:colon \t\n"
            "data:\ttab \n"
            "data: \n"
            "data\n"
            "data: a\vb\fc\u0085d\u2028e\u2029f\n\n",
            [event(" leading:colon \t\n\ttab \n\n\na\vb\fc\u0085d\u2028e\u2029f")],
        )

    def test_empty_data_is_valid_but_other_fields_do_not_dispatch(self):
        self.assert_stream(
            "\n: comment\nunknown\n\n"
            "event: unused\nid: saved\n\n"
            "data\n\ndata:\n\ndata: \n\n",
            [event("", ident="saved")] * 3,
        )

    def test_event_type_defaults_overrides_and_resets(self):
        self.assert_stream(
            "event: abandoned\n\n"
            "data: default\n\n"
            "event: old\nevent: custom\ndata: first\ndata: second\n\n"
            "data: reset\n\n"
            "event: old\nevent:\ndata: empty\n\n"
            "event: old\nevent\ndata: colonless\n\n"
            "event:  spaced \ndata: whitespace\n\n",
            [event("default"), event("first\nsecond", "custom"),
             event("reset"), event("empty"), event("colonless"),
             event("whitespace", " spaced ")],
        )

    def test_id_persists_clears_and_ignores_nul(self):
        self.assert_stream(
            "id: seed\n\ndata: first\n\n"
            "id: bad\0id\n\ndata: retained\n\n"
            "data: changed\nid:  next:part \n\n"
            "id:\n\ndata: cleared\n\n"
            "id: temporary\nid\n\ndata: colonless\n\n"
            "id: final\n\n",
            [event("first", ident="seed"), event("retained", ident="seed"),
             event("changed", ident=" next:part "), event("cleared"),
             event("colonless")],
        )

    def test_only_first_bom_at_stream_start_is_ignored(self):
        self.assert_stream(
            "\ufeff\ufeffdata: ignored\n"
            "data: \ufeffkept\n\n"
            "\ufeffdata: ignored too\n\n",
            [event("\ufeffkept")],
        )
        self.assert_stream("\n\ufeffdata: ignored\n\n", [])
        self.assert_stream("\ufeff", [])

    def test_finish_flushes_line_and_pending_data(self):
        cases = [
            ("", []),
            ("id: only", []),
            ("event: only", []),
            (": only", []),
            ("data", [event("")]),
            ("data:", [event("")]),
            ("data: tail", [event("tail")]),
            ("data: tail\n", [event("tail")]),
            ("data: tail\r", [event("tail")]),
            ("data: tail\r\n", [event("tail")]),
            ("data: tail\nid: last", [event("tail", ident="last")]),
            ("data: tail\nevent: last", [event("tail", "last")]),
        ]
        for text, expected in cases:
            self.assert_stream(text, expected)

    def test_feed_returns_only_newly_completed_events(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: first\n\n"), [event("first")])
        self.assertEqual(
            decoder.feed(b"data: second\n\ndata: third\n\ndata: pending"),
            [event("second"), event("third")],
        )
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.finish(), [event("pending")])

    def test_finish_is_idempotent_and_feed_after_finish_fails(self):
        for prefix in (b"", b"data: pending", b"data: done\n\n"):
            with self.subTest(prefix=prefix):
                decoder = Decoder()
                decoder.feed(prefix)
                decoder.finish()
                self.assertEqual(decoder.finish(), [])
                for chunk in (b"", b"data: late\n\n"):
                    with self.assertRaises(ValueError):
                        decoder.feed(chunk)


if __name__ == "__main__":
    unittest.main()
