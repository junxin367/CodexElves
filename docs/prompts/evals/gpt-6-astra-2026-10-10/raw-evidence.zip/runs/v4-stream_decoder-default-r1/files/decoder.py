import codecs


class Decoder:
    def __init__(self):
        # utf-8-sig consumes exactly one BOM, and only at the start of the stream.
        self._decoder = codecs.getincrementaldecoder("utf-8-sig")()
        self._line = []
        self._skip_lf = False
        self._data = []
        self._event = ""
        self._id = ""
        self._finished = False

    def feed(self, chunk):
        if self._finished:
            raise ValueError("cannot feed a finished stream")
        return self._consume(self._decoder.decode(chunk))

    def finish(self):
        if self._finished:
            return []
        events = self._consume(self._decoder.decode(b"", final=True))
        if self._line:
            self._end_line(events)
        self._dispatch(events)
        self._finished = True
        return events

    def _consume(self, text):
        events = []
        for char in text:
            if self._skip_lf:
                self._skip_lf = False
                if char == "\n":
                    continue
            if char == "\r":
                self._end_line(events)
                self._skip_lf = True
            elif char == "\n":
                self._end_line(events)
            else:
                self._line.append(char)
        return events

    def _end_line(self, events):
        line = "".join(self._line)
        self._line.clear()
        if not line:
            self._dispatch(events)
            return
        if line.startswith(":"):
            return

        field, _, value = line.partition(":")
        if value.startswith(" "):
            value = value[1:]
        if field == "data":
            self._data.append(value)
        elif field == "event":
            self._event = value
        elif field == "id" and "\0" not in value:
            self._id = value

    def _dispatch(self, events):
        if self._data:
            events.append({
                "event": self._event or "message",
                "data": "\n".join(self._data),
                "id": self._id,
            })
        self._data.clear()
        self._event = ""
