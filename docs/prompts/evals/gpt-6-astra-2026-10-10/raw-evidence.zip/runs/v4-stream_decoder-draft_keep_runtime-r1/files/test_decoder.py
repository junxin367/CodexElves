import unittest

from decoder import Decoder


class DecoderTests(unittest.TestCase):
    def assert_stream(self, text, expected):
        raw = text.encode("utf-8")
        chunks = [[raw[:i], b"", raw[i:]] for i in range(len(raw) + 1)]
        chunks.append([bytes([byte]) for byte in raw])
        for index, parts in enumerate(chunks):
            with self.subTest(text=text, partition=index):
                decoder = Decoder()
                events = []
                for part in parts:
                    events.extend(decoder.feed(part))
                events.extend(decoder.finish())
                self.assertEqual(events, expected)
                self.assertEqual(decoder.finish(), [])

    def test_utf8_and_line_endings(self):
        for ending in ("\n", "\r\n", "\r"):
            self.assert_stream(
                f"data: 中文😀{ending}data: café{ending}{ending}",
                [{"event": "message", "data": "中文😀\ncafé", "id": ""}],
            )
        self.assert_stream(
            "data: a\rdata: b\r\n\ndata: c\n\r",
            [
                {"event": "message", "data": "a\nb", "id": ""},
                {"event": "message", "data": "c", "id": ""},
            ],
        )

    def test_feed_dispatches_immediately_and_only_once(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: one\r"), [])
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(
            decoder.feed(b"\r"),
            [{"event": "message", "data": "one", "id": ""}],
        )
        self.assertEqual(decoder.feed(b"\nevent: custom\r"), [])
        self.assertEqual(decoder.feed(b"\ndata: two\r"), [])
        self.assertEqual(
            decoder.feed(b"\n\r"),
            [{"event": "custom", "data": "two", "id": ""}],
        )
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(decoder.finish(), [])

    def test_empty_data_and_no_colon(self):
        self.assert_stream(
            "data\n\ndata:\ndata: \n\n",
            [
                {"event": "message", "data": "", "id": ""},
                {"event": "message", "data": "\n", "id": ""},
            ],
        )

    def test_field_whitespace_and_first_colon(self):
        self.assert_stream(
            "event:  custom \t\nid:\t key  \n"
            "data:  a:b \t\ndata:\tx  \ndata: \n\n",
            [{
                "event": " custom \t",
                "data": " a:b \t\n\tx  \n",
                "id": "\t key  ",
            }],
        )

    def test_comments_unknown_fields_and_exact_names(self):
        self.assert_stream(
            ": data: ignored\nunknown: x\n data: ignored\nData: ignored\n"
            "data : ignored\nretry: 10\n\n"
            "data: kept\n: comment\nunknown\n\n",
            [{"event": "message", "data": "kept", "id": ""}],
        )

    def test_event_reset_and_empty_event(self):
        self.assert_stream(
            "event: discarded\n\n"
            "data: a\n\nevent: first\nevent: last\ndata: b\n\n"
            "data: c\n\nevent: custom\nevent:\ndata: d\n\n"
            "event: custom\nevent\ndata: e",
            [
                {"event": "message", "data": "a", "id": ""},
                {"event": "last", "data": "b", "id": ""},
                {"event": "message", "data": "c", "id": ""},
                {"event": "message", "data": "d", "id": ""},
                {"event": "message", "data": "e", "id": ""},
            ],
        )

    def test_id_persists_clears_and_ignores_nul(self):
        self.assert_stream(
            "id: saved\n\n"
            "data: a\n\nid: bad\0value\n\ndata: b\n\n"
            "id:\n\ndata: c\n\n"
            "id: next\ndata: d\n\nid\n\ndata: e\n\n",
            [
                {"event": "message", "data": "a", "id": "saved"},
                {"event": "message", "data": "b", "id": "saved"},
                {"event": "message", "data": "c", "id": ""},
                {"event": "message", "data": "d", "id": "next"},
                {"event": "message", "data": "e", "id": ""},
            ],
        )

    def test_only_one_leading_bom_is_ignored(self):
        self.assert_stream(
            "\ufeffdata: 中文\n\ndata: \ufeffkept\n\n"
            "\ufeffdata: ignored\n\n",
            [
                {"event": "message", "data": "中文", "id": ""},
                {"event": "message", "data": "\ufeffkept", "id": ""},
            ],
        )
        self.assert_stream("\ufeff\ufeffdata: ignored\n\n", [])
        self.assert_stream("\n\ufeffdata: ignored\n\n", [])

    def test_other_unicode_separators_are_data(self):
        self.assert_stream(
            "data: a\u0085b\u2028c\u2029d\v\f\0\n\n",
            [{"event": "message", "data": "a\u0085b\u2028c\u2029d\v\f\0", "id": ""}],
        )

    def test_finish_unterminated_lines_and_events(self):
        for text in ("data: tail", "data: tail\n", "data: tail\r", "data: tail\r\n"):
            self.assert_stream(
                text, [{"event": "message", "data": "tail", "id": ""}],
            )
        self.assert_stream(
            "data: tail\nevent: custom\nid: final",
            [{"event": "custom", "data": "tail", "id": "final"}],
        )
        self.assert_stream(
            "data", [{"event": "message", "data": "", "id": ""}],
        )
        self.assert_stream(
            "data: tail\n: comment",
            [{"event": "message", "data": "tail", "id": ""}],
        )

    def test_no_data_means_no_event(self):
        for text in ("", "\ufeff", "\n\r\n\r", ": comment", "id: only", "event: only"):
            self.assert_stream(text, [])

    def test_finish_is_idempotent_and_feed_after_finish_raises(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: pending"), [])
        self.assertEqual(
            decoder.finish(),
            [{"event": "message", "data": "pending", "id": ""}],
        )
        self.assertEqual(decoder.finish(), [])
        for chunk in (b"", b"data: too late\n\n"):
            with self.assertRaises(ValueError):
                decoder.feed(chunk)
        self.assertEqual(decoder.finish(), [])


if __name__ == "__main__":
    unittest.main()
