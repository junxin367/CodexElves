import asyncio


class Cache:
    def __init__(self, clock):
        self.clock = clock
        self.values = {}
        self._inflight = {}
        self._tasks = set()

    async def get(self, key, loader, ttl):
        if key in self.values:
            value, expires = self.values[key]
            if self.clock() < expires:
                return value
            self.values.pop(key)
        future = self._inflight.get(key)
        if future is None:
            future = asyncio.get_running_loop().create_future()
            future.add_done_callback(lambda done: done.exception())
            self._inflight[key] = future
            task = asyncio.create_task(self._load(key, loader, ttl, future))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
        return await asyncio.shield(future)

    async def _load(self, key, loader, ttl, future):
        try:
            value = await loader()
            if self._inflight.get(key) is future and ttl > 0:
                self.values[key] = (value, self.clock() + ttl)
            future.set_result(value)
        except (Exception, asyncio.CancelledError) as exc:
            future.set_exception(exc)
        finally:
            if self._inflight.get(key) is future:
                del self._inflight[key]

    def invalidate(self, key):
        self.values.pop(key, None)
        self._inflight.pop(key, None)
