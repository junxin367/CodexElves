import asyncio
import unittest

from cache import Cache


class CacheTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.now = 0
        self.cache = Cache(lambda: self.now)

    async def start_get(self, loader, ttl=10, key="k"):
        entered = asyncio.Event()

        async def get():
            entered.set()
            return await self.cache.get(key, loader, ttl)

        task = asyncio.create_task(get())
        await entered.wait()
        return task

    async def unexpected_load(self):
        self.fail("loader should not run")

    async def test_expiry_boundary_and_completion_time(self):
        started = asyncio.Event()
        release = asyncio.Event()

        async def load():
            started.set()
            await release.wait()
            return "value"

        task = await self.start_get(load, ttl=5)
        await started.wait()
        self.now = 100
        release.set()
        self.assertEqual(await task, "value")
        self.now = 104
        self.assertEqual(
            await self.cache.get("k", self.unexpected_load, 99), "value"
        )
        self.now = 105
        calls = 0

        async def reload():
            nonlocal calls
            calls += 1
            return "new"

        self.assertEqual(await self.cache.get("k", reload, 5), "new")
        self.assertEqual(calls, 1)

    async def test_shared_result_and_first_loader_and_ttl(self):
        started = asyncio.Event()
        release = asyncio.Event()
        value = object()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            started.set()
            await release.wait()
            return value

        first = await self.start_get(load, ttl=5)
        await started.wait()
        others = [
            await self.start_get(self.unexpected_load, ttl=100)
            for _ in range(5)
        ]
        release.set()
        for result in await asyncio.gather(first, *others):
            self.assertIs(result, value)
        self.assertEqual(calls, 1)
        self.now = 5
        self.assertIs(await self.cache.get("k", load, 5), value)
        self.assertEqual(calls, 2)

    async def test_nonpositive_ttl_shares_only_inflight_result(self):
        for ttl in (0, -1):
            with self.subTest(ttl=ttl):
                release = asyncio.Event()
                calls = 0

                async def load():
                    nonlocal calls
                    calls += 1
                    await release.wait()
                    return calls

                first = await self.start_get(load, ttl=ttl)
                second = await self.start_get(self.unexpected_load, ttl=100)
                release.set()
                self.assertEqual(await asyncio.gather(first, second), [1, 1])
                self.assertNotIn("k", self.cache.values)
                self.assertEqual(await self.cache.get("k", load, ttl), 2)

    async def test_shared_failure_and_retry(self):
        release = asyncio.Event()
        error = ValueError("load failed")
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            if calls == 1:
                raise error
            return "retry"

        first = await self.start_get(load)
        second = await self.start_get(self.unexpected_load)
        release.set()
        results = await asyncio.gather(first, second, return_exceptions=True)
        self.assertTrue(all(result is error for result in results))
        self.assertEqual(calls, 1)
        self.assertNotIn("k", self.cache.values)
        self.assertEqual(await self.cache.get("k", load, 10), "retry")
        self.assertEqual(calls, 2)

    async def test_cancelling_either_waiter_does_not_cancel_loader(self):
        for cancelled_index in (0, 1):
            with self.subTest(cancelled_index=cancelled_index):
                self.cache.invalidate("k")
                started = asyncio.Event()
                release = asyncio.Event()

                async def load():
                    started.set()
                    await release.wait()
                    return "value"

                first = await self.start_get(load)
                await started.wait()
                second = await self.start_get(self.unexpected_load)
                tasks = [first, second]
                tasks[cancelled_index].cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await tasks[cancelled_index]
                self.assertFalse(tasks[1 - cancelled_index].done())
                release.set()
                self.assertEqual(await tasks[1 - cancelled_index], "value")
                self.assertEqual(
                    await self.cache.get("k", self.unexpected_load, 10), "value"
                )

    async def test_sole_waiter_cancellation_keeps_shared_load(self):
        started = asyncio.Event()
        release = asyncio.Event()

        async def load():
            started.set()
            await release.wait()
            return "value"

        first = await self.start_get(load)
        await started.wait()
        first.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await first
        second = await self.start_get(self.unexpected_load)
        release.set()
        self.assertEqual(await second, "value")

    async def test_invalidate_isolates_old_success_and_failure(self):
        for fails in (False, True):
            for old_finishes_first in (False, True):
                with self.subTest(
                    fails=fails, old_finishes_first=old_finishes_first
                ):
                    self.cache.invalidate("k")
                    old_started = asyncio.Event()
                    new_started = asyncio.Event()
                    old_release = asyncio.Event()
                    new_release = asyncio.Event()
                    error = ValueError("old load failed")

                    async def old_load():
                        old_started.set()
                        await old_release.wait()
                        if fails:
                            raise error
                        return "old"

                    async def new_load():
                        new_started.set()
                        await new_release.wait()
                        return "new"

                    old = await self.start_get(old_load)
                    await old_started.wait()
                    old_waiter = await self.start_get(self.unexpected_load)
                    self.cache.invalidate("k")
                    new = await self.start_get(new_load)
                    await new_started.wait()

                    async def finish_old():
                        old_release.set()
                        results = await asyncio.gather(
                            old, old_waiter, return_exceptions=True
                        )
                        if fails:
                            self.assertTrue(all(r is error for r in results))
                        else:
                            self.assertEqual(results, ["old", "old"])

                    if old_finishes_first:
                        await finish_old()
                        joining = await self.start_get(self.unexpected_load)
                        self.assertFalse(joining.done())
                        new_release.set()
                        self.assertEqual(
                            await asyncio.gather(new, joining), ["new", "new"]
                        )
                    else:
                        new_release.set()
                        self.assertEqual(await new, "new")
                        await finish_old()
                    self.assertEqual(
                        await self.cache.get("k", self.unexpected_load, 10),
                        "new",
                    )

    async def test_invalidate_cached_value_and_missing_key(self):
        self.cache.invalidate("missing")
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            return calls

        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.cache.invalidate("k")
        self.assertEqual(await self.cache.get("k", load, 10), 2)

    async def test_different_keys_load_independently(self):
        release = asyncio.Event()

        async def blocked():
            await release.wait()
            return "first"

        async def immediate():
            return "second"

        first = await self.start_get(blocked, key="first")
        self.assertEqual(await self.cache.get("second", immediate, 10), "second")
        self.assertFalse(first.done())
        release.set()
        self.assertEqual(await first, "first")


if __name__ == "__main__":
    unittest.main()
