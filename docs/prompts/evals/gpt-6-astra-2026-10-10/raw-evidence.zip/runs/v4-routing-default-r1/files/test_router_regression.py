import copy
import unittest

from router import resolve


class ResolveRegression(unittest.TestCase):
    def test_alias_priority_and_first_alias(self):
        mappings = [
            {"requestModel": " name ", "systemPromptOverride": "wrong"},
            {"alias": " name ", "requestModel": " first ",
             "systemPromptOverride": " right ", "protocol": " chat "},
            {"alias": "name", "requestModel": "second"},
        ]
        self.assertEqual(
            resolve(" \tname\n", mappings),
            {"model": "first", "prompt": "right", "protocol": "chat"},
        )

    def test_first_request_model_match(self):
        mappings = [
            {"alias": "other", "requestModel": " target ",
             "systemPromptOverride": " first "},
            {"requestModel": "target", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" target ", mappings)["prompt"], "first")

    def test_invalid_request_models_are_ignored(self):
        for invalid in ({}, {"requestModel": ""},
                        {"requestModel": " \t\n"}, {"requestModel": None}):
            with self.subTest(invalid=invalid):
                mappings = [
                    dict(invalid, alias="name", systemPromptOverride="wrong"),
                    {"requestModel": " name ", "systemPromptOverride": "right"},
                ]
                self.assertEqual(resolve("name", mappings)["prompt"], "right")
                self.assertEqual(resolve(" name ", mappings[:1])["model"], "name")

    def test_blank_or_missing_alias_still_allows_request_model_match(self):
        for alias in (None, "", " \t\n"):
            with self.subTest(alias=alias):
                self.assertEqual(
                    resolve("name", [{"alias": alias, "requestModel": " name ",
                                      "systemPromptOverride": "matched"}])["prompt"],
                    "matched",
                )

    def test_only_one_mapping_layer(self):
        mappings = [
            {"alias": "first", "requestModel": " second ",
             "systemPromptOverride": "one", "protocol": "chat"},
            {"alias": "second", "requestModel": "third",
             "systemPromptOverride": "two", "protocol": "other"},
        ]
        self.assertEqual(
            resolve("first", mappings),
            {"model": "second", "prompt": "one", "protocol": "chat"},
        )

    def test_prompt_fallbacks(self):
        for override, supplier, expected in (
            (" override ", " supplier ", "override"),
            (" \t\n", " supplier ", "supplier"),
            ("", " supplier ", "supplier"),
            (None, " supplier ", "supplier"),
            (" \t", "\n ", " DEFAULT \n"),
            (None, "", " DEFAULT \n"),
        ):
            with self.subTest(override=override, supplier=supplier):
                self.assertEqual(
                    resolve("name", [{"requestModel": "name",
                                      "systemPromptOverride": override}],
                            supplier, " DEFAULT \n")["prompt"],
                    expected,
                )

    def test_protocol_fallbacks(self):
        for protocol, expected in (
            (" chat \n", "chat"),
            (" \t\n", " default "),
            ("", " default "),
            (None, " default "),
        ):
            with self.subTest(protocol=protocol):
                self.assertEqual(
                    resolve("name", [{"requestModel": "name", "protocol": protocol}],
                            default_protocol=" default ")["protocol"],
                    expected,
                )

    def test_unmatched_model_and_defaults(self):
        self.assertEqual(
            resolve(" unknown ", [{"requestModel": "other"}],
                    default_prompt=" DEFAULT \n", default_protocol=" custom "),
            {"model": "unknown", "prompt": " DEFAULT \n", "protocol": " custom "},
        )
        self.assertEqual(
            resolve("unknown", [], supplier_prompt=" supplier ")["prompt"],
            "supplier",
        )

    def test_empty_input_raises(self):
        for name in ("", " ", "\t\r\n"):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_unchanged(self):
        mappings = [
            {"alias": " name ", "requestModel": " target ",
             "systemPromptOverride": " prompt ", "protocol": " chat ",
             "metadata": {"tags": ["keep"]}},
            {"alias": "invalid", "requestModel": " "},
        ]
        original = copy.deepcopy(mappings)
        for name in ("name", "target", "invalid", "unknown"):
            resolve(name, mappings)
            self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
