def resolve(name, mappings, supplier_prompt="", default_prompt="DEFAULT", default_protocol="responses"):
    name = name.strip()
    if not name:
        raise ValueError("Model name must not be blank")

    valid = []
    for mapping in mappings:
        model = (mapping.get("requestModel") or "").strip()
        if model:
            alias = (mapping.get("alias") or "").strip()
            valid.append((mapping, model, alias))

    match = next((item for item in valid if item[2] and item[2] == name), None)
    if match is None:
        match = next((item for item in valid if item[1] == name), None)

    entry, model = (match[0], match[1]) if match is not None else ({}, name)
    prompt = (
        (entry.get("systemPromptOverride") or "").strip()
        or (supplier_prompt or "").strip()
        or default_prompt
    )
    protocol = (entry.get("protocol") or "").strip() or default_protocol
    return {"model": model, "prompt": prompt, "protocol": protocol}
