import copy
import unittest

from router import resolve


class ResolveRegression(unittest.TestCase):
    def test_alias_priority_and_first_valid_alias(self):
        mappings = [
            {"requestModel": " name ", "systemPromptOverride": "wrong"},
            {"alias": " name ", "requestModel": " \t "},
            {"alias": " name "},
            {"alias": " name ", "requestModel": " first ",
             "systemPromptOverride": " right ", "protocol": " chat "},
            {"alias": "name", "requestModel": "second"},
        ]
        self.assertEqual(
            resolve(" name ", mappings),
            {"model": "first", "prompt": "right", "protocol": "chat"},
        )

    def test_first_request_model_match(self):
        mappings = [
            {"requestModel": " target ", "alias": " ",
             "systemPromptOverride": " first "},
            {"requestModel": "target", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve("\ttarget\n", mappings)["prompt"], "first")

    def test_only_one_mapping_layer(self):
        mappings = [
            {"alias": "a", "requestModel": "b", "systemPromptOverride": "one"},
            {"alias": "b", "requestModel": "c", "systemPromptOverride": "two"},
        ]
        self.assertEqual(
            resolve("a", mappings),
            {"model": "b", "prompt": "one", "protocol": "responses"},
        )

    def test_prompt_fallbacks(self):
        for override, supplier, expected in [
            (" override ", " supplier ", "override"),
            (" \t\n", " supplier ", "supplier"),
            ("", " \t\n", " DEFAULT \n"),
            (None, None, " DEFAULT \n"),
        ]:
            with self.subTest(override=override, supplier=supplier):
                result = resolve(
                    "x", [{"requestModel": "x", "systemPromptOverride": override}],
                    supplier_prompt=supplier, default_prompt=" DEFAULT \n",
                )
                self.assertEqual(result["prompt"], expected)

    def test_protocol_fallback_preserves_default(self):
        for protocol in ["", " \t\n", None]:
            with self.subTest(protocol=protocol):
                self.assertEqual(
                    resolve("x", [{"requestModel": "x", "protocol": protocol}],
                            default_protocol=" default ")["protocol"],
                    " default ",
                )

    def test_unknown_model_and_invalid_mappings(self):
        mappings = [
            {"alias": "unknown", "requestModel": "",
             "systemPromptOverride": "wrong", "protocol": "wrong"},
            {"alias": "unknown", "requestModel": None},
        ]
        self.assertEqual(
            resolve(" unknown ", mappings, supplier_prompt=" supplier "),
            {"model": "unknown", "prompt": "supplier", "protocol": "responses"},
        )

    def test_empty_input_raises(self):
        for name in ["", " ", "\t\r\n"]:
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "x"}])

    def test_does_not_mutate_mappings(self):
        mappings = [
            {"alias": " a ", "requestModel": " b ",
             "systemPromptOverride": " prompt ", "protocol": " chat "},
            {"alias": " a ", "requestModel": " "},
        ]
        original = copy.deepcopy(mappings)
        resolve("a", mappings)
        resolve("b", mappings)
        resolve("unknown", mappings)
        self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
