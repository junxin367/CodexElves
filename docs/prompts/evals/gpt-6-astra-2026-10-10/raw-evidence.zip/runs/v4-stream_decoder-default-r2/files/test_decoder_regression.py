import unittest

from decoder import Decoder


def event(data, kind="message", event_id=""):
    return {"event": kind, "data": data, "id": event_id}


class DecoderRegression(unittest.TestCase):
    def assert_stream(self, text, expected):
        payload = text.encode("utf-8")
        # Every possible two-chunk boundary, plus fully bytewise delivery.
        chunkings = [
            (payload[:offset], payload[offset:])
            for offset in range(len(payload) + 1)
        ]
        chunkings.append([bytes([byte]) for byte in payload])
        for chunks in chunkings:
            with self.subTest(chunks=chunks):
                decoder = Decoder()
                actual = []
                for chunk in chunks:
                    actual.extend(decoder.feed(chunk))
                actual.extend(decoder.finish())
                self.assertEqual(actual, expected)
                self.assertEqual(decoder.finish(), [])

    def test_utf8_bom_and_mixed_line_endings(self):
        self.assert_stream(
            "\ufeffid: 标识\r\nevent: 更新\rdata: 中文🙂\n"
            "data: 第二行\r\n\r\ndata: 末尾",
            [
                event("中文🙂\n第二行", "更新", "标识"),
                event("末尾", event_id="标识"),
            ],
        )

    def test_line_endings_dispatch_during_feed(self):
        for ending in ("\n", "\r", "\r\n"):
            with self.subTest(ending=ending):
                decoder = Decoder()
                self.assertEqual(
                    decoder.feed(("data: x" + ending * 2).encode()),
                    [event("x")],
                )
                self.assertEqual(decoder.finish(), [])

    def test_split_crlf_is_not_an_extra_blank_line(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: a\r"), [])
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\ndata: b\r"), [])
        self.assertEqual(decoder.feed(b"\n\r"), [event("a\nb")])
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(decoder.finish(), [])

    def test_empty_data_and_fields_without_colons(self):
        self.assert_stream(
            "data\n\n"
            "data:\ndata: \n\n"
            "event: custom\nevent\ndata: x\n\n",
            [event(""), event("\n"), event("x")],
        )

    def test_preserve_whitespace_and_split_first_colon(self):
        self.assert_stream(
            "event:  custom \nid:  key \n"
            "data:  a:b \t\ndata:\tb \ndata: \n\n",
            [event(" a:b \t\n\tb \n", " custom ", " key ")],
        )

    def test_comments_unknown_fields_and_unicode_separators(self):
        self.assert_stream(
            ":data: ignored\nunknown: value\n data: ignored\n"
            "Data: ignored\n\n"
            "data: a\u2028b\u2029c\v\f\n: comment\nretry: 1\n\n",
            [event("a\u2028b\u2029c\v\f")],
        )

    def test_event_resets_on_every_blank_line(self):
        self.assert_stream(
            "event: unused\n\n"
            "data: a\n\nevent: first\nevent: last\ndata: b\n\n"
            "data: c\n\nevent:\ndata: d\n\n",
            [event("a"), event("b", "last"), event("c"), event("d")],
        )

    def test_id_persists_without_data_and_empty_id_clears(self):
        self.assert_stream(
            "id: first\n\n"
            "data: a\n\nid: bad\0id\n\ndata: b\n\n"
            "id:\n\ndata: c\n\n"
            "id: second\n\ndata: d\n\nid\n\ndata: e\n\n",
            [
                event("a", event_id="first"),
                event("b", event_id="first"),
                event("c"),
                event("d", event_id="second"),
                event("e"),
            ],
        )

    def test_id_changes_before_dispatch(self):
        self.assert_stream(
            "data: a\nid: latest\n\ndata: b\nid: final",
            [event("a", event_id="latest"), event("b", event_id="final")],
        )

    def test_only_one_initial_bom_is_ignored(self):
        self.assert_stream(
            "\ufeff\ufeffdata: ignored\n\n"
            "data: \ufeffkept\n\n\ufeffdata: ignored\n\n",
            [event("\ufeffkept")],
        )

    def test_finish_flushes_unterminated_data(self):
        for suffix in ("", "\n", "\r", "\r\n"):
            with self.subTest(suffix=suffix):
                decoder = Decoder()
                self.assertEqual(decoder.feed(("data: x" + suffix).encode()), [])
                self.assertEqual(decoder.finish(), [event("x")])
                self.assertEqual(decoder.finish(), [])
        self.assert_stream("data", [event("")])
        self.assert_stream("data:", [event("")])
        self.assert_stream("data: x\nevent: final", [event("x", "final")])
        self.assert_stream("data: x\n: trailing comment", [event("x")])

    def test_no_data_produces_no_event(self):
        for text in ("", "\ufeff", "\n\r\n\r", "id: x", "event: x\n\n", ": hi"):
            with self.subTest(text=text):
                self.assert_stream(text, [])

    def test_feed_after_finish_raises(self):
        decoder = Decoder()
        self.assertEqual(decoder.finish(), [])
        for chunk in (b"", b"data: x\n\n"):
            with self.subTest(chunk=chunk):
                with self.assertRaises(ValueError):
                    decoder.feed(chunk)


if __name__ == "__main__":
    unittest.main()
