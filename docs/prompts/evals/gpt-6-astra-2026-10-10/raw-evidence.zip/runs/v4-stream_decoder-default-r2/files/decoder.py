import codecs


class Decoder:
    def __init__(self):
        # utf-8-sig consumes only the initial BOM, even across byte chunks.
        self._decoder = codecs.getincrementaldecoder("utf-8-sig")()
        self._line = []
        self._skip_lf = False
        self._data = []
        self._event = ""
        self._id = ""
        self._finished = False

    def feed(self, chunk):
        if self._finished:
            raise ValueError("cannot feed a finished stream")
        events = []
        self._consume(self._decoder.decode(chunk), events)
        return events

    def finish(self):
        if self._finished:
            return []
        self._finished = True
        events = []
        self._consume(self._decoder.decode(b"", final=True), events)
        if self._line:
            self._process_line()
        self._dispatch(events)
        return events

    def _consume(self, text, events):
        for char in text:
            if self._skip_lf:
                self._skip_lf = False
                if char == "\n":
                    continue
            if char in "\r\n":
                # Process CR immediately; swallow only its following LF.
                self._skip_lf = char == "\r"
                if self._line:
                    self._process_line()
                else:
                    self._dispatch(events)
            else:
                self._line.append(char)

    def _process_line(self):
        line = "".join(self._line)
        self._line.clear()
        if line.startswith(":"):
            return
        field, _, value = line.partition(":")
        if value.startswith(" "):
            value = value[1:]
        if field == "data":
            self._data.append(value)
        elif field == "event":
            self._event = value
        elif field == "id" and "\0" not in value:
            self._id = value

    def _dispatch(self, events):
        if self._data:
            events.append({
                "event": self._event or "message",
                "data": "\n".join(self._data),
                "id": self._id,
            })
        self._data.clear()
        self._event = ""
