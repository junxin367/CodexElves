import copy
import unittest

from router import resolve


class ResolveTests(unittest.TestCase):
    def test_alias_priority_and_first_alias(self):
        mappings = [
            {"requestModel": " model ", "systemPromptOverride": "wrong"},
            {"alias": " model ", "requestModel": " first "},
            {"alias": "model", "requestModel": "second"},
        ]
        self.assertEqual(resolve(" \tmodel\n", mappings), {
            "model": "first", "prompt": "DEFAULT", "protocol": "responses",
        })

    def test_first_request_model_match(self):
        mappings = [
            {"requestModel": " model ", "systemPromptOverride": " first "},
            {"requestModel": "model", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" model ", mappings)["prompt"], "first")

    def test_invalid_mappings_are_skipped(self):
        invalid = [
            {"alias": "model"},
            {"alias": "model", "requestModel": None},
            {"alias": "model", "requestModel": ""},
            {"alias": "model", "requestModel": " \t\n"},
        ]
        for valid in (
            {"alias": " model ", "requestModel": "target"},
            {"requestModel": " model "},
        ):
            with self.subTest(valid=valid):
                self.assertEqual(
                    resolve("model", invalid + [valid])["model"],
                    valid["requestModel"].strip(),
                )
        self.assertEqual(resolve(" model ", invalid)["model"], "model")

    def test_empty_alias_does_not_block_request_model_match(self):
        for alias in (None, "", " \t\n"):
            with self.subTest(alias=alias):
                self.assertEqual(resolve("model", [
                    {"alias": alias, "requestModel": " model ",
                     "systemPromptOverride": "matched"},
                ])["prompt"], "matched")

    def test_only_one_mapping_layer(self):
        mappings = [
            {"alias": "a", "requestModel": " b ",
             "systemPromptOverride": " first ", "protocol": " chat "},
            {"alias": "b", "requestModel": "c",
             "systemPromptOverride": "second", "protocol": "other"},
        ]
        self.assertEqual(resolve("a", mappings), {
            "model": "b", "prompt": "first", "protocol": "chat",
        })
        mappings[1]["requestModel"] = "a"
        self.assertEqual(resolve("a", mappings)["model"], "b")

    def test_prompt_fallbacks(self):
        for override in (None, "", " \t\n", " override \n"):
            for supplier in (None, "", " \t\n", " supplier \n"):
                for default in (" default \n", "", " \t\n"):
                    with self.subTest(
                        override=override, supplier=supplier, default=default
                    ):
                        expected = (
                            "override" if override == " override \n"
                            else "supplier" if supplier == " supplier \n"
                            else default
                        )
                        self.assertEqual(resolve("model", [
                            {"requestModel": "model",
                             "systemPromptOverride": override},
                        ], supplier, default)["prompt"], expected)

    def test_protocol_fallbacks(self):
        for protocol in (None, "", " \t\n", " chat \n"):
            with self.subTest(protocol=protocol):
                self.assertEqual(resolve("model", [
                    {"requestModel": "model", "protocol": protocol},
                ], default_protocol=" default \n")["protocol"],
                    "chat" if protocol == " chat \n" else " default \n")

    def test_unmatched_model_and_defaults(self):
        mappings = [{"requestModel": "other",
                     "systemPromptOverride": "ignored", "protocol": "ignored"}]
        self.assertEqual(resolve(" unknown \n", mappings, " supplier "),
                         {"model": "unknown", "prompt": "supplier",
                          "protocol": "responses"})
        self.assertEqual(resolve(" unknown ", mappings, " \t", " default \n",
                                 " custom "),
                         {"model": "unknown", "prompt": " default \n",
                          "protocol": " custom "})

    def test_empty_input_raises(self):
        for name in ("", " ", "\t\r\n"):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_unchanged(self):
        mappings = [
            {"alias": " model ", "requestModel": " \t"},
            {"alias": " model ", "requestModel": " target ",
             "systemPromptOverride": " prompt ", "protocol": " chat "},
            {"requestModel": " target "},
        ]
        original = copy.deepcopy(mappings)
        for name in ("model", "target", "unknown", ""):
            with self.subTest(name=name):
                if name:
                    resolve(name, mappings)
                else:
                    with self.assertRaises(ValueError):
                        resolve(name, mappings)
                self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
