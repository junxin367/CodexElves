import asyncio


class _Load:
    def __init__(self):
        self.task = None


class Cache:
    def __init__(self, clock):
        self.clock = clock
        self.values = {}
        self._inflight = {}
        # Keep detached loads alive after invalidation or waiter cancellation.
        self._tasks = set()

    async def get(self, key, loader, ttl):
        if key in self.values:
            value, expires = self.values[key]
            if self.clock() < expires:
                return value
            self.values.pop(key)

        load = self._inflight.get(key)
        if load is None:
            load = _Load()
            # Publish identity before starting the task, including when an
            # eager task factory runs the loader immediately.
            self._inflight[key] = load
            load.task = asyncio.create_task(self._load(key, loader, ttl, load))
            self._tasks.add(load.task)
            load.task.add_done_callback(self._load_done)

        return await asyncio.shield(load.task)

    async def _load(self, key, loader, ttl, load):
        try:
            value = await loader()
            if ttl > 0 and self._inflight.get(key) is load:
                self.values[key] = (value, self.clock() + ttl)
            return value
        finally:
            # An invalidated load must never remove its replacement.
            if self._inflight.get(key) is load:
                self._inflight.pop(key)

    def _load_done(self, task):
        self._tasks.discard(task)
        # Retrieve failures even if every waiter has already been cancelled.
        if not task.cancelled():
            task.exception()

    def invalidate(self, key):
        self.values.pop(key, None)
        self._inflight.pop(key, None)
