import asyncio
import gc
import unittest

from cache import Cache


class Clock:
    def __init__(self):
        self.now = 0

    def __call__(self):
        return self.now


class Loader:
    def __init__(self, value=None, error=None):
        self.value = value
        self.error = error
        self.calls = 0
        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def __call__(self):
        self.calls += 1
        self.started.set()
        await self.release.wait()
        if self.error is not None:
            raise self.error
        return self.value


class CacheTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.clock = Clock()
        self.cache = Cache(self.clock)

    async def start_get(self, loader, ttl=10, key="k"):
        entered = asyncio.Event()

        async def request():
            entered.set()
            return await self.cache.get(key, loader, ttl)

        task = asyncio.create_task(request())
        # request reaches get's first suspension before this wait resumes.
        await entered.wait()
        return task

    async def test_expiry_boundary_and_completion_time(self):
        loader = Loader("value")
        waiter = await self.start_get(loader)
        await loader.started.wait()
        self.clock.now = 100
        loader.release.set()
        self.assertEqual(await waiter, "value")
        self.assertEqual(self.cache.values["k"], ("value", 110))

        replacement = Loader("replacement")
        replacement.release.set()
        self.clock.now = 109
        self.assertEqual(await self.cache.get("k", replacement, 10), "value")
        self.assertEqual(replacement.calls, 0)
        self.clock.now = 110
        self.assertEqual(await self.cache.get("k", replacement, 10), "replacement")
        self.assertEqual(replacement.calls, 1)

    async def test_shared_result_uses_first_loader_and_ttl(self):
        value = object()
        first = Loader(value)
        other = Loader("wrong")
        one = await self.start_get(first, ttl=5)
        two = await self.start_get(other, ttl=100)
        await first.started.wait()
        self.clock.now = 20
        first.release.set()
        results = await asyncio.gather(one, two)
        self.assertTrue(all(result is value for result in results))
        self.assertEqual(first.calls, 1)
        self.assertEqual(other.calls, 0)
        self.assertEqual(self.cache.values["k"], (value, 25))

    async def test_nonpositive_ttl_shares_but_does_not_cache(self):
        for ttl in (0, -10):
            with self.subTest(ttl=ttl):
                first = Loader(object())
                other = Loader("unused")
                one = await self.start_get(first, ttl=ttl)
                two = await self.start_get(other, ttl=100)
                first.release.set()
                results = await asyncio.gather(one, two)
                self.assertTrue(all(result is first.value for result in results))
                self.assertEqual(first.calls, 1)
                self.assertEqual(other.calls, 0)
                self.assertNotIn("k", self.cache.values)
                self.assertIs(await self.cache.get("k", first, ttl), first.value)
                self.assertEqual(first.calls, 2)

    async def test_failure_is_shared_and_retryable(self):
        error = ValueError("failed")
        first = Loader(error=error)
        other = Loader("retry")
        one = await self.start_get(first)
        two = await self.start_get(other)
        first.release.set()
        results = await asyncio.gather(one, two, return_exceptions=True)
        self.assertTrue(all(result is error for result in results))
        self.assertEqual(first.calls, 1)
        self.assertEqual(other.calls, 0)
        self.assertNotIn("k", self.cache.values)
        other.release.set()
        self.assertEqual(await self.cache.get("k", other, 10), "retry")
        self.assertEqual(other.calls, 1)

    async def test_cancelled_waiter_does_not_cancel_shared_loader(self):
        for cancel_first in (True, False):
            with self.subTest(cancel_first=cancel_first):
                self.cache.invalidate("k")
                loader = Loader("value")
                one = await self.start_get(loader)
                two = await self.start_get(loader)
                await loader.started.wait()
                cancelled, survivor = (one, two) if cancel_first else (two, one)
                cancelled.cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await cancelled
                three = await self.start_get(loader)
                loader.release.set()
                self.assertEqual(await asyncio.gather(survivor, three),
                                 ["value", "value"])
                self.assertEqual(loader.calls, 1)

    async def test_all_waiters_cancelled_load_remains_joinable(self):
        loader = Loader("value")
        one = await self.start_get(loader)
        two = await self.start_get(loader)
        await loader.started.wait()
        one.cancel()
        two.cancel()
        await asyncio.gather(one, two, return_exceptions=True)
        replacement = Loader("wrong")
        three = await self.start_get(replacement)
        loader.release.set()
        self.assertEqual(await three, "value")
        self.assertEqual(loader.calls, 1)
        self.assertEqual(replacement.calls, 0)

    async def test_abandoned_failure_is_retrieved(self):
        loop = asyncio.get_running_loop()
        reports = []
        previous = loop.get_exception_handler()
        loop.set_exception_handler(lambda loop, context: reports.append(context))
        try:
            loader = Loader(error=ValueError("abandoned"))
            waiter = await self.start_get(loader)
            await loader.started.wait()
            shared = self.cache._inflight["k"].task
            waiter.cancel()
            with self.assertRaises(asyncio.CancelledError):
                await waiter
            done = asyncio.Event()
            shared.add_done_callback(lambda task: done.set())
            loader.release.set()
            await done.wait()
            self.assertNotIn("k", self.cache._inflight)
            self.assertFalse(self.cache._tasks)
            del shared, waiter, loader
            gc.collect()
            self.assertEqual(reports, [])
        finally:
            loop.set_exception_handler(previous)

    async def test_invalidate_old_completion_cannot_remove_new_load(self):
        for fails in (False, True):
            with self.subTest(fails=fails):
                self.cache.invalidate("k")
                error = ValueError("old failure") if fails else None
                old = Loader("old", error=error)
                old_waiter = await self.start_get(old)
                await old.started.wait()
                self.cache.invalidate("k")
                new = Loader("new")
                new_waiter = await self.start_get(new)
                await new.started.wait()
                old.release.set()
                result = (await asyncio.gather(old_waiter, return_exceptions=True))[0]
                if fails:
                    self.assertIs(result, error)
                else:
                    self.assertEqual(result, "old")
                self.assertNotIn("k", self.cache.values)
                unused = Loader("wrong")
                joiner = await self.start_get(unused)
                new.release.set()
                self.assertEqual(await asyncio.gather(new_waiter, joiner),
                                 ["new", "new"])
                self.assertEqual(unused.calls, 0)
                self.assertEqual(new.calls, 1)

    async def test_invalidate_old_completion_cannot_overwrite_new_cache(self):
        for fails in (False, True):
            with self.subTest(fails=fails):
                self.cache.invalidate("k")
                old = Loader("old", error=ValueError("old") if fails else None)
                old_waiter = await self.start_get(old, ttl=100)
                self.cache.invalidate("k")
                new = Loader("new")
                new.release.set()
                self.assertEqual(await self.cache.get("k", new, 5), "new")
                old.release.set()
                await asyncio.gather(old_waiter, return_exceptions=True)
                self.assertEqual(self.cache.values["k"], ("new", 5))
                self.assertEqual(await self.cache.get("k", new, 10), "new")
                self.assertEqual(new.calls, 1)

    async def test_repeated_invalidation_separates_generations(self):
        loaders = [Loader(object()) for _ in range(3)]
        waiters = []
        for loader in loaders:
            self.cache.invalidate("k")
            waiters.append(await self.start_get(loader))
            await loader.started.wait()
        for index in (1, 2, 0):
            loaders[index].release.set()
            self.assertIs(await waiters[index], loaders[index].value)
        self.assertIs(self.cache.values["k"][0], loaders[2].value)
        self.assertEqual([loader.calls for loader in loaders], [1, 1, 1])

    async def test_keys_load_independently_and_cached_value_invalidates(self):
        blocked = Loader("blocked")
        waiter = await self.start_get(blocked, key="a")
        quick = Loader("quick")
        quick.release.set()
        self.assertEqual(await self.cache.get("b", quick, 10), "quick")
        self.cache.invalidate("b")
        self.assertEqual(await self.cache.get("b", quick, 10), "quick")
        self.assertEqual(quick.calls, 2)
        self.assertFalse(waiter.done())
        blocked.release.set()
        self.assertEqual(await waiter, "blocked")


if __name__ == "__main__":
    unittest.main()
