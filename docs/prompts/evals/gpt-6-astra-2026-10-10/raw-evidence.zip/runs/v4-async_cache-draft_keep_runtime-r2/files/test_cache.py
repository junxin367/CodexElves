import asyncio
import unittest

from cache import Cache


class CacheTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.now = 0
        self.cache = Cache(lambda: self.now)

    async def start_get(self, loader, ttl=10, key="k"):
        entered = asyncio.Event()

        async def get():
            entered.set()
            return await self.cache.get(key, loader, ttl)

        task = asyncio.create_task(get())
        await entered.wait()
        return task

    async def test_expiry_boundary(self):
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            return calls

        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.now = 9
        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.now = 10
        self.assertEqual(await self.cache.get("k", load, 10), 2)
        self.now = 21
        self.assertEqual(await self.cache.get("k", load, 10), 3)

    async def test_ttl_starts_at_success(self):
        started = asyncio.Event()
        release = asyncio.Event()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            started.set()
            await release.wait()
            return calls

        task = await self.start_get(load)
        await started.wait()
        self.now = 100
        release.set()
        self.assertEqual(await task, 1)
        self.now = 109
        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.now = 110
        self.assertEqual(await self.cache.get("k", load, 10), 2)

    async def test_shared_loader_and_first_ttl(self):
        release = asyncio.Event()
        calls = 0
        value = object()

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            return value

        async def unused():
            self.fail("A joining caller must not run its loader")

        first = await self.start_get(load, 10)
        others = [await self.start_get(unused, 100) for _ in range(5)]
        release.set()
        results = await asyncio.gather(first, *others)
        self.assertTrue(all(result is value for result in results))
        self.assertEqual(calls, 1)
        self.now = 9
        self.assertIs(await self.cache.get("k", unused, 100), value)
        self.now = 10
        self.assertIs(await self.cache.get("k", load, 100), value)
        self.assertEqual(calls, 2)

    async def test_nonpositive_ttl_shares_but_does_not_cache(self):
        for ttl in (0, -10):
            with self.subTest(ttl=ttl):
                release = asyncio.Event()
                calls = 0

                async def load():
                    nonlocal calls
                    calls += 1
                    await release.wait()
                    return calls

                first = await self.start_get(load, ttl)
                second = await self.start_get(load, 100)
                release.set()
                self.assertEqual(await asyncio.gather(first, second), [1, 1])
                self.assertNotIn("k", self.cache.values)
                self.assertEqual(await self.cache.get("k", load, ttl), 2)

    async def test_shared_failure_and_retry(self):
        release = asyncio.Event()
        error = ValueError("load failed")
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            if calls == 1:
                raise error
            return "retried"

        first = await self.start_get(load)
        second = await self.start_get(load)
        release.set()
        results = await asyncio.gather(first, second, return_exceptions=True)
        self.assertTrue(all(result is error for result in results))
        self.assertEqual(calls, 1)
        self.assertNotIn("k", self.cache.values)
        self.assertEqual(await self.cache.get("k", load, 10), "retried")
        self.assertEqual(calls, 2)

    async def test_cancelled_waiter_does_not_cancel_shared_load(self):
        for cancel_first in (True, False):
            with self.subTest(cancel_first=cancel_first):
                self.cache.invalidate("k")
                release = asyncio.Event()
                calls = 0

                async def load():
                    nonlocal calls
                    calls += 1
                    await release.wait()
                    return "value"

                first = await self.start_get(load)
                second = await self.start_get(load)
                cancelled, survivor = (first, second) if cancel_first else (second, first)
                cancelled.cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await cancelled
                third = await self.start_get(load)
                release.set()
                self.assertEqual(await asyncio.gather(survivor, third), ["value", "value"])
                self.assertEqual(calls, 1)
                self.assertEqual(await self.cache.get("k", load, 10), "value")
                self.assertEqual(calls, 1)

    async def test_load_survives_all_waiters_cancelling(self):
        release = asyncio.Event()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            return "value"

        first = await self.start_get(load)
        second = await self.start_get(load)
        first.cancel()
        second.cancel()
        await asyncio.gather(first, second, return_exceptions=True)
        third = await self.start_get(load)
        release.set()
        self.assertEqual(await third, "value")
        self.assertEqual(calls, 1)

    async def test_invalidate_isolates_generations(self):
        for old_fails in (False, True):
            for new_finishes_first in (False, True):
                with self.subTest(old_fails=old_fails, new_finishes_first=new_finishes_first):
                    self.cache.invalidate("k")
                    old_release = asyncio.Event()
                    new_release = asyncio.Event()
                    new_started = asyncio.Event()
                    error = ValueError("old failed")
                    calls = 0

                    async def old_load():
                        await old_release.wait()
                        if old_fails:
                            raise error
                        return "old"

                    async def new_load():
                        nonlocal calls
                        calls += 1
                        new_started.set()
                        await new_release.wait()
                        return "new"

                    old = await self.start_get(old_load)
                    old_joiner = await self.start_get(old_load)
                    self.cache.invalidate("k")
                    new = await self.start_get(new_load)
                    await asyncio.wait_for(new_started.wait(), 1)
                    if new_finishes_first:
                        new_release.set()
                        self.assertEqual(await new, "new")
                    old_release.set()
                    old_results = await asyncio.gather(old, old_joiner, return_exceptions=True)
                    if old_fails:
                        self.assertTrue(all(result is error for result in old_results))
                    else:
                        self.assertEqual(old_results, ["old", "old"])
                    joiner = await self.start_get(new_load)
                    new_release.set()
                    self.assertEqual(await asyncio.gather(new, joiner), ["new", "new"])
                    self.assertEqual(await self.cache.get("k", new_load, 10), "new")
                    self.assertEqual(calls, 1)

    async def test_invalidate_cached_and_missing_keys(self):
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            return calls

        self.cache.invalidate("missing")
        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.cache.invalidate("k")
        self.assertEqual(await self.cache.get("k", load, 10), 2)

    async def test_invalidated_load_does_not_repopulate_cache(self):
        release = asyncio.Event()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            return calls

        old = await self.start_get(load)
        self.cache.invalidate("k")
        release.set()
        self.assertEqual(await old, 1)
        self.assertNotIn("k", self.cache.values)
        self.assertEqual(await self.cache.get("k", load, 10), 2)

    async def test_loader_cancellation_allows_retry(self):
        release = asyncio.Event()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            if calls == 1:
                raise asyncio.CancelledError
            return "retried"

        first = await self.start_get(load)
        second = await self.start_get(load)
        release.set()
        results = await asyncio.gather(first, second, return_exceptions=True)
        self.assertTrue(all(isinstance(result, asyncio.CancelledError) for result in results))
        self.assertEqual(calls, 1)
        self.assertEqual(await self.cache.get("k", load, 10), "retried")

    async def test_different_keys_load_independently(self):
        release = asyncio.Event()

        async def slow():
            await release.wait()
            return "slow"

        async def fast():
            return "fast"

        task = await self.start_get(slow)
        self.assertEqual(await self.cache.get("other", fast, 10), "fast")
        self.assertFalse(task.done())
        release.set()
        self.assertEqual(await task, "slow")


if __name__ == "__main__":
    unittest.main()
