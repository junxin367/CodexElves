import asyncio


class Cache:
    def __init__(self, clock):
        self.clock = clock
        self.values = {}
        self._inflight = {}
        self._tasks = set()

    async def get(self, key, loader, ttl):
        if key in self.values:
            value, expires = self.values[key]
            if self.clock() < expires:
                return value
            self.values.pop(key, None)
        task = self._inflight.get(key)
        if task is None:
            task = asyncio.create_task(self._load(key, loader, ttl))
            self._inflight[key] = task
            self._tasks.add(task)
            task.add_done_callback(self._finished)
        return await asyncio.shield(task)

    async def _load(self, key, loader, ttl):
        task = asyncio.current_task()
        try:
            value = await loader()
            if self._inflight.get(key) is task and ttl > 0:
                self.values[key] = (value, self.clock() + ttl)
            return value
        finally:
            if self._inflight.get(key) is task:
                self._inflight.pop(key)

    def _finished(self, task):
        self._tasks.discard(task)
        if not task.cancelled():
            task.exception()

    def invalidate(self, key):
        self.values.pop(key, None)
        self._inflight.pop(key, None)
