import asyncio


class _Load:
    def __init__(self):
        self.task = None


class Cache:
    def __init__(self, clock):
        self.clock = clock
        self.values = {}
        self._loads = {}

    async def get(self, key, loader, ttl):
        if key in self.values:
            value, expires = self.values[key]
            if self.clock() < expires:
                return value
            self.values.pop(key, None)

        load = self._loads.get(key)
        if load is None:
            load = _Load()
            # Publish the generation before starting the coroutine, including
            # when an eager task factory is installed.
            self._loads[key] = load
            load.task = asyncio.create_task(self._load(key, loader, ttl, load))
            load.task.add_done_callback(self._observe_exception)
        return await asyncio.shield(load.task)

    async def _load(self, key, loader, ttl, load):
        try:
            value = await loader()
            if self._loads.get(key) is load and ttl > 0:
                self.values[key] = (value, self.clock() + ttl)
            return value
        finally:
            # An invalidated generation must not remove its replacement.
            if self._loads.get(key) is load:
                del self._loads[key]

    @staticmethod
    def _observe_exception(task):
        # Retrieve failures even when every waiter has already been cancelled.
        if not task.cancelled():
            task.exception()

    def invalidate(self, key):
        self.values.pop(key, None)
        self._loads.pop(key, None)
