import asyncio
import unittest

from cache import Cache


class Clock:
    def __init__(self):
        self.now = 0

    def __call__(self):
        return self.now


class ControlledLoader:
    def __init__(self, result=None, error=None):
        self.result = result
        self.error = error
        self.calls = 0
        self.started = asyncio.Event()
        self.release = asyncio.Event()

    async def __call__(self):
        self.calls += 1
        self.started.set()
        await self.release.wait()
        if self.error is not None:
            raise self.error
        return self.result


class CacheRegression(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.clock = Clock()
        self.cache = Cache(self.clock)

    async def start_get(self, loader, ttl=10, key="k"):
        task = asyncio.create_task(self.cache.get(key, loader, ttl))
        # Let get reach its first suspension without relying on elapsed time.
        checkpoint = asyncio.get_running_loop().create_future()
        asyncio.get_running_loop().call_soon(checkpoint.set_result, None)
        await checkpoint
        return task

    async def test_expiry_is_strict_and_ttl_starts_at_completion(self):
        loader = ControlledLoader("value")
        task = await self.start_get(loader, ttl=5)
        await loader.started.wait()
        self.clock.now = 100
        loader.release.set()
        self.assertEqual(await task, "value")
        self.clock.now = 104
        self.assertEqual(await self.cache.get("k", loader, 5), "value")
        self.assertEqual(loader.calls, 1)
        self.clock.now = 105
        self.assertEqual(await self.cache.get("k", loader, 5), "value")
        self.assertEqual(loader.calls, 2)

    async def test_concurrent_misses_use_first_loader_and_ttl(self):
        value = object()
        first = ControlledLoader(value)
        other = ControlledLoader("wrong")
        other.release.set()
        tasks = [await self.start_get(first, ttl=5)]
        tasks.extend([await self.start_get(other, ttl=100) for _ in range(8)])
        first.release.set()
        results = await asyncio.gather(*tasks)
        self.assertTrue(all(result is value for result in results))
        self.assertEqual(first.calls, 1)
        self.assertEqual(other.calls, 0)
        self.clock.now = 5
        self.assertEqual(await self.cache.get("k", other, 100), "wrong")
        self.assertEqual(other.calls, 1)

    async def test_nonpositive_ttl_shares_load_but_does_not_store(self):
        for ttl in (0, -10):
            with self.subTest(ttl=ttl):
                loader = ControlledLoader("value")
                first = await self.start_get(loader, ttl)
                second = await self.start_get(loader, 100)
                loader.release.set()
                self.assertEqual(await asyncio.gather(first, second),
                                 ["value", "value"])
                self.assertEqual(loader.calls, 1)
                self.assertNotIn("k", self.cache.values)
                self.assertEqual(await self.cache.get("k", loader, ttl), "value")
                self.assertEqual(loader.calls, 2)

    async def test_failure_is_shared_and_can_be_retried(self):
        error = RuntimeError("load failed")
        loader = ControlledLoader(error=error)
        first = await self.start_get(loader)
        second = await self.start_get(loader)
        loader.release.set()
        results = await asyncio.gather(first, second, return_exceptions=True)
        self.assertTrue(all(result is error for result in results))
        self.assertEqual(loader.calls, 1)
        loader.error = None
        loader.result = "recovered"
        self.assertEqual(await self.cache.get("k", loader, 10), "recovered")
        self.assertEqual(loader.calls, 2)

    async def test_cancelling_a_waiter_preserves_shared_load(self):
        loader = ControlledLoader("value")
        first = await self.start_get(loader)
        second = await self.start_get(loader)
        first.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await first
        third = await self.start_get(loader)
        loader.release.set()
        self.assertEqual(await asyncio.gather(second, third), ["value", "value"])
        self.assertEqual(loader.calls, 1)
        self.assertEqual(await self.cache.get("k", loader, 10), "value")
        self.assertEqual(loader.calls, 1)

    async def test_cancelling_every_waiter_preserves_loader(self):
        loader = ControlledLoader("value")
        first = await self.start_get(loader)
        await loader.started.wait()
        shared = self.cache._loads["k"].task
        first.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await first
        self.assertFalse(shared.done())
        loader.release.set()
        self.assertEqual(await shared, "value")
        self.assertEqual(await self.cache.get("k", loader, 10), "value")
        self.assertEqual(loader.calls, 1)

    async def test_abandoned_failure_is_observed_and_retryable(self):
        loader = ControlledLoader(error=RuntimeError("abandoned"))
        first = await self.start_get(loader)
        shared = self.cache._loads["k"].task
        first.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await first
        finished = asyncio.Event()
        shared.add_done_callback(lambda task: finished.set())
        loader.release.set()
        await finished.wait()
        self.assertNotIn("k", self.cache._loads)
        self.assertNotIn("k", self.cache.values)
        loader.error = None
        loader.result = "recovered"
        self.assertEqual(await self.cache.get("k", loader, 10), "recovered")
        self.assertEqual(loader.calls, 2)

    async def test_old_completion_cannot_remove_new_pending_load(self):
        for fail in (False, True):
            with self.subTest(fail=fail):
                self.cache.invalidate("k")
                error = RuntimeError("old failure") if fail else None
                old = ControlledLoader("old", error)
                new = ControlledLoader("new")
                old_task = await self.start_get(old)
                self.cache.invalidate("k")
                new_task = await self.start_get(new)
                await new.started.wait()
                old.release.set()
                result = (await asyncio.gather(old_task,
                                               return_exceptions=True))[0]
                self.assertIs(result, error) if fail else self.assertEqual(result, "old")
                self.assertNotIn("k", self.cache.values)
                unexpected = ControlledLoader("unexpected")
                unexpected.release.set()
                joined = await self.start_get(unexpected)
                self.assertFalse(joined.done())
                new.release.set()
                self.assertEqual(await asyncio.gather(new_task, joined),
                                 ["new", "new"])
                self.assertEqual(new.calls, 1)
                self.assertEqual(unexpected.calls, 0)

    async def test_old_completion_cannot_overwrite_new_cached_value(self):
        for fail in (False, True):
            with self.subTest(fail=fail):
                self.cache.invalidate("k")
                error = RuntimeError("old failure") if fail else None
                old = ControlledLoader("old", error)
                new = ControlledLoader("new")
                old_task = await self.start_get(old)
                self.cache.invalidate("k")
                new_task = await self.start_get(new)
                new.release.set()
                self.assertEqual(await new_task, "new")
                old.release.set()
                result = (await asyncio.gather(old_task,
                                               return_exceptions=True))[0]
                self.assertIs(result, error) if fail else self.assertEqual(result, "old")
                self.assertEqual(await self.cache.get("k", old, 10), "new")
                self.assertEqual(old.calls, 1)

    async def test_invalidate_cached_value_and_independent_keys(self):
        first = ControlledLoader("first")
        second = ControlledLoader("second")
        first_task = await self.start_get(first, key="a")
        second_task = await self.start_get(second, key="b")
        second.release.set()
        self.assertEqual(await second_task, "second")
        self.assertFalse(first_task.done())
        first.release.set()
        self.assertEqual(await first_task, "first")
        self.cache.invalidate("a")
        self.assertEqual(await self.cache.get("a", first, 10), "first")
        self.assertEqual(first.calls, 2)
        self.assertEqual(await self.cache.get("b", second, 10), "second")
        self.assertEqual(second.calls, 1)


if __name__ == "__main__":
    unittest.main()
