import unittest

from decoder import Decoder


class DecoderTests(unittest.TestCase):
    def assert_stream(self, text, expected):
        raw = text.encode("utf-8")
        chunks = [[raw], [bytes([byte]) for byte in raw]]
        chunks.extend([raw[:i], b"", raw[i:]] for i in range(len(raw) + 1))
        for index, parts in enumerate(chunks):
            with self.subTest(text=text, chunking=index):
                decoder = Decoder()
                actual = []
                for part in parts:
                    actual.extend(decoder.feed(part))
                actual.extend(decoder.finish())
                self.assertEqual(actual, expected)
                self.assertEqual(decoder.finish(), [])
                with self.assertRaises(ValueError):
                    decoder.feed(b"")
                with self.assertRaises(ValueError):
                    decoder.feed(b"data: late\n\n")

    def test_utf8_and_line_endings(self):
        for ending in ("\n", "\r\n", "\r"):
            self.assert_stream(
                ending.join(("data: 中文😀", "data: café", "", "")),
                [{"event": "message", "data": "中文😀\ncafé", "id": ""}],
            )
        self.assert_stream(
            "data: a\r\ndata: b\rdata: c\n\r\n",
            [{"event": "message", "data": "a\nb\nc", "id": ""}],
        )

    def test_fields_and_whitespace(self):
        self.assert_stream(
            ": data: ignored\nunknown: ignored\n data: ignored\n"
            "data:  leading \t \ndata:\tvalue:tail \t\n"
            "data\ndata:\ndata: \n\n",
            [{
                "event": "message",
                "data": " leading \t \n\tvalue:tail \t\n\n\n",
                "id": "",
            }],
        )
        self.assert_stream(
            "data: \v\f\u0085\u2028\u2029\0\n\n",
            [{"event": "message", "data": "\v\f\u0085\u2028\u2029\0", "id": ""}],
        )

    def test_empty_data(self):
        for field in ("data", "data:", "data: "):
            self.assert_stream(
                field + "\n\n",
                [{"event": "message", "data": "", "id": ""}],
            )

    def test_event_type_and_reset(self):
        self.assert_stream(
            "event: discarded\n\n"
            "data: first\n\n"
            "event: old\nevent: custom\ndata: second\n\n"
            "data: third\n\n"
            "event: old\nevent:\ndata: fourth\n\n"
            "event: old\nevent\ndata: fifth\n\n"
            "event:  custom \t\ndata: sixth\n\n",
            [
                {"event": "message", "data": "first", "id": ""},
                {"event": "custom", "data": "second", "id": ""},
                {"event": "message", "data": "third", "id": ""},
                {"event": "message", "data": "fourth", "id": ""},
                {"event": "message", "data": "fifth", "id": ""},
                {"event": " custom \t", "data": "sixth", "id": ""},
            ],
        )

    def test_persistent_id(self):
        self.assert_stream(
            "id: saved\n\n"
            "data: first\n\n"
            "id: bad\0id\n\ndata: second\n\n"
            "id:\n\ndata: third\n\n"
            "id:  spaced: id \t\ndata: fourth\n\n"
            "id\n\ndata: fifth\n\n"
            "data: sixth\nid: last",
            [
                {"event": "message", "data": "first", "id": "saved"},
                {"event": "message", "data": "second", "id": "saved"},
                {"event": "message", "data": "third", "id": ""},
                {"event": "message", "data": "fourth", "id": " spaced: id \t"},
                {"event": "message", "data": "fifth", "id": ""},
                {"event": "message", "data": "sixth", "id": "last"},
            ],
        )

    def test_bom_only_at_stream_start(self):
        self.assert_stream(
            "\ufeffdata: first\n\ndata: \ufeffkept\n\n"
            "\ufeffdata: ignored\n\n",
            [
                {"event": "message", "data": "first", "id": ""},
                {"event": "message", "data": "\ufeffkept", "id": ""},
            ],
        )
        self.assert_stream(
            "\ufeff\ufeffdata: ignored\n\ndata: kept",
            [{"event": "message", "data": "kept", "id": ""}],
        )
        self.assert_stream("\n\ufeffdata: ignored\n\n", [])

    def test_finish_unterminated_event(self):
        for ending in ("", "\n", "\r", "\r\n"):
            self.assert_stream(
                "event: custom\nid: saved\ndata: 中文" + ending,
                [{"event": "custom", "data": "中文", "id": "saved"}],
            )
        self.assert_stream("data", [{"event": "message", "data": "", "id": ""}])
        self.assert_stream(
            "data: first\ndata: second",
            [{"event": "message", "data": "first\nsecond", "id": ""}],
        )

    def test_no_data_no_event(self):
        for text in ("", "\ufeff", "\r\n\r\n", ": comment", "event: type\nid: id"):
            self.assert_stream(text, [])

    def test_feed_dispatch_timing(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"id: saved\r"), [])
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\n\r"), [])
        self.assertEqual(decoder.feed(b"\ndata: one\r"), [])
        self.assertEqual(
            decoder.feed(b"\n\r"),
            [{"event": "message", "data": "one", "id": "saved"}],
        )
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(
            decoder.feed(b"data: two\n\ndata: three\r\rdata: four"),
            [
                {"event": "message", "data": "two", "id": "saved"},
                {"event": "message", "data": "three", "id": "saved"},
            ],
        )
        self.assertEqual(
            decoder.finish(),
            [{"event": "message", "data": "four", "id": "saved"}],
        )
        self.assertEqual(decoder.finish(), [])


if __name__ == "__main__":
    unittest.main()
