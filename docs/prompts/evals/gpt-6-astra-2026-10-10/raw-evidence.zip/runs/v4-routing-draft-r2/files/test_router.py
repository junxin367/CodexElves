import copy
import unittest

from router import resolve


class ResolveTests(unittest.TestCase):
    def test_trimmed_alias_has_priority(self):
        mappings = [
            {"requestModel": " alias ", "systemPromptOverride": "wrong"},
            {"alias": " alias ", "requestModel": " target ",
             "systemPromptOverride": " right ", "protocol": " chat "},
        ]
        self.assertEqual(resolve(" \talias\n", mappings),
                         {"model": "target", "prompt": "right", "protocol": "chat"})

    def test_first_alias_match_wins(self):
        mappings = [
            {"alias": " x ", "requestModel": " first "},
            {"alias": "x", "requestModel": "second"},
        ]
        self.assertEqual(resolve("x", mappings)["model"], "first")

    def test_first_request_model_match_wins(self):
        mappings = [
            {"requestModel": " x ", "systemPromptOverride": " first "},
            {"requestModel": "x", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" x ", mappings)["prompt"], "first")

    def test_invalid_mappings_are_ignored(self):
        for target in (None, "", " \t\n"):
            with self.subTest(target=target):
                mappings = [
                    {"alias": "x", "systemPromptOverride": "wrong"},
                    {"alias": " x ", "requestModel": target,
                     "systemPromptOverride": "wrong", "protocol": "wrong"},
                    {"requestModel": " x ", "systemPromptOverride": "right"},
                ]
                self.assertEqual(resolve("x", mappings),
                                 {"model": "x", "prompt": "right",
                                  "protocol": "responses"})
                self.assertEqual(resolve(" x ", mappings[:2]),
                                 {"model": "x", "prompt": "DEFAULT",
                                  "protocol": "responses"})

    def test_blank_alias_does_not_prevent_request_model_match(self):
        for alias in (None, "", " \t\n"):
            with self.subTest(alias=alias):
                mappings = [{"alias": alias, "requestModel": " x ",
                             "systemPromptOverride": "matched"}]
                self.assertEqual(resolve("x", mappings)["prompt"], "matched")

    def test_mapping_is_not_recursive(self):
        mappings = [
            {"alias": "a", "requestModel": "b", "systemPromptOverride": "first"},
            {"alias": "b", "requestModel": "c", "systemPromptOverride": "second"},
            {"alias": "c", "requestModel": "a"},
        ]
        self.assertEqual(resolve("a", mappings),
                         {"model": "b", "prompt": "first", "protocol": "responses"})

    def test_prompt_fallback_order(self):
        cases = [
            (" override ", " supplier ", "override"),
            (" \t\n", " supplier ", "supplier"),
            ("", " supplier ", "supplier"),
            (None, " supplier ", "supplier"),
            (" \n", " \t", " DEFAULT \n"),
            (None, None, " DEFAULT \n"),
        ]
        for override, supplier, expected in cases:
            with self.subTest(override=override, supplier=supplier):
                mappings = [{"requestModel": "x", "systemPromptOverride": override}]
                self.assertEqual(resolve("x", mappings, supplier, " DEFAULT \n")["prompt"],
                                 expected)
        self.assertEqual(resolve("x", [], default_prompt="")["prompt"], "")

    def test_protocol_fallback(self):
        for protocol in (None, "", " \t\n"):
            with self.subTest(protocol=protocol):
                mappings = [{"requestModel": "x", "protocol": protocol}]
                self.assertEqual(
                    resolve("x", mappings, default_protocol=" default \n")["protocol"],
                    " default \n")

    def test_unmatched_name_and_defaults(self):
        mappings = [{"requestModel": "other", "systemPromptOverride": "wrong",
                     "protocol": "wrong"}]
        self.assertEqual(resolve(" unknown \n", mappings, " supplier "),
                         {"model": "unknown", "prompt": "supplier",
                          "protocol": "responses"})
        self.assertEqual(resolve(" unknown ", mappings, " \t", " default \n"),
                         {"model": "unknown", "prompt": " default \n",
                          "protocol": "responses"})

    def test_empty_input_raises(self):
        for name in ("", " ", "\t\r\n"):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_not_modified(self):
        mappings = [
            {"alias": " x ", "requestModel": " target ",
             "systemPromptOverride": " override ", "protocol": " chat ",
             "extra": {"values": [1, 2]}},
            {"alias": "bad", "requestModel": " \n"},
            {},
        ]
        original = copy.deepcopy(mappings)
        for name in ("x", "target", "unknown"):
            resolve(name, mappings)
            self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
