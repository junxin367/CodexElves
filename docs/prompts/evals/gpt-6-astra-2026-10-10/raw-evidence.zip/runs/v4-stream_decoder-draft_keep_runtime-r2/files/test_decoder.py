import unittest

from decoder import Decoder


class DecoderTests(unittest.TestCase):
    def assert_stream(self, text, expected):
        payload = text.encode("utf-8")
        chunkings = [
            [payload],
            [bytes([byte]) for byte in payload],
        ]
        chunkings.extend(
            [payload[:index], b"", payload[index:]]
            for index in range(len(payload) + 1)
        )
        for chunks in chunkings:
            with self.subTest(chunks=chunks):
                decoder = Decoder()
                events = []
                for chunk in chunks:
                    events.extend(decoder.feed(chunk))
                events.extend(decoder.finish())
                self.assertEqual(events, expected)
                self.assertEqual(decoder.finish(), [])

    def test_utf8_bom_and_mixed_line_endings(self):
        self.assert_stream(
            "\ufeffid: 中文\r\nevent: 更新\rdata: 你好😀\ndata: 第二行\r\n\r\n"
            "data: 尾声\r\r",
            [
                {"event": "更新", "data": "你好😀\n第二行", "id": "中文"},
                {"event": "message", "data": "尾声", "id": "中文"},
            ],
        )

    def test_line_endings(self):
        for ending in ("\n", "\r\n", "\r"):
            with self.subTest(ending=ending):
                self.assert_stream(
                    ending.join(["data: one", "", "data: two", "", ""]),
                    [
                        {"event": "message", "data": "one", "id": ""},
                        {"event": "message", "data": "two", "id": ""},
                    ],
                )

    def test_feed_returns_only_completed_events(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: one\r"), [])
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(
            decoder.feed(b"\r"),
            [{"event": "message", "data": "one", "id": ""}],
        )
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(decoder.feed(b"\ndata: two\r"), [])
        self.assertEqual(
            decoder.feed(b"\rdata: three\n\n"),
            [
                {"event": "message", "data": "two", "id": ""},
                {"event": "message", "data": "three", "id": ""},
            ],
        )
        self.assertEqual(decoder.finish(), [])

    def test_fields_preserve_whitespace_and_colons(self):
        self.assert_stream(
            ": data: ignored\nunknown: ignored\n data: ignored\nDATA: ignored\n"
            "id:  key:part \t\nevent:  custom \t\n"
            "data:  first:second \t\ndata:\tthird \n"
            "data\ndata:\ndata: \n\n",
            [{
                "event": " custom \t",
                "data": " first:second \t\n\tthird \n\n\n",
                "id": " key:part \t",
            }],
        )

    def test_empty_data_is_an_event(self):
        self.assert_stream(
            "data\n\ndata:\n\ndata: \n\n",
            [{"event": "message", "data": "", "id": ""}] * 3,
        )

    def test_event_resets_even_without_data(self):
        self.assert_stream(
            "event: discarded\n\n"
            "data: one\n\n"
            "event: old\nevent: custom\ndata: two\n\n"
            "data: three\n\n"
            "event: old\nevent:\ndata: four\n\n"
            "event: old\nevent\ndata: five\n\n",
            [
                {"event": "message", "data": "one", "id": ""},
                {"event": "custom", "data": "two", "id": ""},
                {"event": "message", "data": "three", "id": ""},
                {"event": "message", "data": "four", "id": ""},
                {"event": "message", "data": "five", "id": ""},
            ],
        )

    def test_id_persists_clears_and_ignores_nul(self):
        self.assert_stream(
            "id: first\n\n"
            "data: one\n\n"
            "id: bad\0id\n\n"
            "data: two\n\n"
            "id:\n\n"
            "data: three\nid: last\n\n"
            "data: four\n\n"
            "id\n\n"
            "data: five\n\n",
            [
                {"event": "message", "data": "one", "id": "first"},
                {"event": "message", "data": "two", "id": "first"},
                {"event": "message", "data": "three", "id": "last"},
                {"event": "message", "data": "four", "id": "last"},
                {"event": "message", "data": "five", "id": ""},
            ],
        )

    def test_only_one_initial_bom_is_ignored(self):
        self.assert_stream(
            "\ufeff\ufeffdata: ignored\n\ndata: \ufeffkept\n\n"
            "\ufeffid: ignored\ndata: next\n\n",
            [
                {"event": "message", "data": "\ufeffkept", "id": ""},
                {"event": "message", "data": "next", "id": ""},
            ],
        )
        self.assert_stream(
            "\n\ufeffdata: ignored\n\ndata: kept",
            [{"event": "message", "data": "kept", "id": ""}],
        )

    def test_non_ascii_line_separators_are_data(self):
        self.assert_stream(
            "data: a\u0085b\u2028c\u2029d\v\f\0\n\n",
            [{"event": "message", "data": "a\u0085b\u2028c\u2029d\v\f\0", "id": ""}],
        )

    def test_finish_processes_unterminated_lines_and_events(self):
        for tail in ("", "\n", "\r", "\r\n"):
            with self.subTest(tail=tail):
                self.assert_stream(
                    "data: final" + tail,
                    [{"event": "message", "data": "final", "id": ""}],
                )
        self.assert_stream(
            "data: final\nid: tail",
            [{"event": "message", "data": "final", "id": "tail"}],
        )
        self.assert_stream(
            "data: final\nevent: custom",
            [{"event": "custom", "data": "final", "id": ""}],
        )
        self.assert_stream(
            "data",
            [{"event": "message", "data": "", "id": ""}],
        )

    def test_no_event_without_data(self):
        for text in ("", "\ufeff", "\r\n\r\n", ": comment", "id: key", "event: custom"):
            with self.subTest(text=text):
                self.assert_stream(text, [])

    def test_finish_is_final(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: final"), [])
        self.assertEqual(
            decoder.finish(),
            [{"event": "message", "data": "final", "id": ""}],
        )
        self.assertEqual(decoder.finish(), [])
        for chunk in (b"", b"data: later\n\n"):
            with self.subTest(chunk=chunk):
                with self.assertRaises(ValueError):
                    decoder.feed(chunk)


if __name__ == "__main__":
    unittest.main()
