import asyncio
import unittest

from cache import Cache


class CacheTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.now = 0
        self.cache = Cache(lambda: self.now)

    async def start_get(self, loader, ttl=10, key="k"):
        task = asyncio.create_task(self.cache.get(key, loader, ttl))
        ready = asyncio.get_running_loop().create_future()
        asyncio.get_running_loop().call_soon(ready.set_result, None)
        await ready
        return task

    async def test_expiry_boundary_and_completion_time(self):
        started = asyncio.Event()
        release = asyncio.Event()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            started.set()
            await release.wait()
            return calls

        first = await self.start_get(load)
        await started.wait()
        self.now = 100
        release.set()
        self.assertEqual(await first, 1)
        self.now = 109
        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.now = 110
        self.assertEqual(await self.cache.get("k", load, 10), 2)
        self.assertEqual(calls, 2)

    async def test_nonpositive_ttl_shares_but_does_not_store(self):
        for ttl in (0, -1):
            with self.subTest(ttl=ttl):
                release = asyncio.Event()
                calls = 0
                result = object()

                async def load():
                    nonlocal calls
                    calls += 1
                    await release.wait()
                    return result

                first = await self.start_get(load, ttl)
                second = await self.start_get(load, 100)
                self.assertEqual(calls, 1)
                release.set()
                self.assertIs(await first, result)
                self.assertIs(await second, result)
                self.assertNotIn("k", self.cache.values)
                self.assertIs(await self.cache.get("k", load, ttl), result)
                self.assertEqual(calls, 2)

    async def test_first_loader_and_ttl_win(self):
        release = asyncio.Event()
        result = object()
        calls = 0

        async def first_load():
            nonlocal calls
            calls += 1
            await release.wait()
            return result

        async def other_load():
            return "other"

        first = await self.start_get(first_load, 5)
        others = [await self.start_get(other_load, 100) for _ in range(5)]
        release.set()
        for value in await asyncio.gather(first, *others):
            self.assertIs(value, result)
        self.assertEqual(calls, 1)
        self.now = 4
        self.assertIs(await self.cache.get("k", other_load, 100), result)
        self.now = 5
        self.assertEqual(await self.cache.get("k", other_load, 100), "other")

    async def test_failure_is_shared_and_retryable(self):
        release = asyncio.Event()
        error = ValueError("failed")
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            if calls == 1:
                raise error
            return "retry"

        waiters = [await self.start_get(load) for _ in range(5)]
        self.assertEqual(calls, 1)
        release.set()
        for outcome in await asyncio.gather(*waiters, return_exceptions=True):
            self.assertIs(outcome, error)
        self.assertEqual(await self.cache.get("k", load, 10), "retry")
        self.assertEqual(calls, 2)

    async def test_cancelling_either_waiter_does_not_cancel_loader(self):
        for cancelled_index in (0, 1):
            with self.subTest(cancelled_index=cancelled_index):
                self.cache.invalidate("k")
                release = asyncio.Event()
                calls = 0

                async def load():
                    nonlocal calls
                    calls += 1
                    await release.wait()
                    return "value"

                waiters = [await self.start_get(load) for _ in range(2)]
                waiters[cancelled_index].cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await waiters[cancelled_index]
                third = await self.start_get(load)
                release.set()
                self.assertEqual(await waiters[1 - cancelled_index], "value")
                self.assertEqual(await third, "value")
                self.assertEqual(calls, 1)
                self.assertEqual(await self.cache.get("k", load, 10), "value")
                self.assertEqual(calls, 1)

    async def test_loader_survives_cancellation_of_all_waiters(self):
        release = asyncio.Event()
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            await release.wait()
            return "value"

        first = await self.start_get(load)
        first.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await first
        second = await self.start_get(load)
        release.set()
        self.assertEqual(await second, "value")
        self.assertEqual(calls, 1)

    async def test_invalidation_isolates_old_completion_and_failure(self):
        for old_fails in (False, True):
            for new_finishes_first in (False, True):
                with self.subTest(
                    old_fails=old_fails,
                    new_finishes_first=new_finishes_first,
                ):
                    self.cache.invalidate("k")
                    old_release = asyncio.Event()
                    new_release = asyncio.Event()
                    old_error = ValueError("old failure")
                    new_calls = 0

                    async def old_load():
                        await old_release.wait()
                        if old_fails:
                            raise old_error
                        return "old"

                    async def new_load():
                        nonlocal new_calls
                        new_calls += 1
                        await new_release.wait()
                        return "new"

                    async def unexpected_load():
                        self.fail("request joined neither new load nor new cache")

                    old = await self.start_get(old_load)
                    old_waiter = await self.start_get(old_load)
                    self.cache.invalidate("k")
                    new = await self.start_get(new_load)
                    self.assertEqual(new_calls, 1)
                    if new_finishes_first:
                        new_release.set()
                        self.assertEqual(await new, "new")
                    old_release.set()
                    outcomes = await asyncio.gather(
                        old, old_waiter, return_exceptions=True
                    )
                    for outcome in outcomes:
                        if old_fails:
                            self.assertIs(outcome, old_error)
                        else:
                            self.assertEqual(outcome, "old")
                    latest = await self.start_get(unexpected_load)
                    new_release.set()
                    self.assertEqual(await new, "new")
                    self.assertEqual(await latest, "new")
                    self.assertEqual(
                        await self.cache.get("k", unexpected_load, 10), "new"
                    )
                    self.assertEqual(new_calls, 1)

    async def test_invalidate_cached_and_missing_keys(self):
        calls = 0

        async def load():
            nonlocal calls
            calls += 1
            return calls

        self.cache.invalidate("missing")
        self.assertEqual(await self.cache.get("k", load, 10), 1)
        self.cache.invalidate("k")
        self.assertEqual(await self.cache.get("k", load, 10), 2)

    async def test_different_keys_load_independently(self):
        release = asyncio.Event()

        async def blocked_load():
            await release.wait()
            return "blocked"

        async def other_load():
            return "other"

        blocked = await self.start_get(blocked_load)
        self.assertEqual(await self.cache.get("other", other_load, 10), "other")
        self.assertFalse(blocked.done())
        release.set()
        self.assertEqual(await blocked, "blocked")


if __name__ == "__main__":
    unittest.main()
