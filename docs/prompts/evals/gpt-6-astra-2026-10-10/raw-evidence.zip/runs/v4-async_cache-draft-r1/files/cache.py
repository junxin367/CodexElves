import asyncio


class Cache:
    def __init__(self, clock):
        self.clock = clock
        self.values = {}
        self._loads = {}
        self._tasks = set()

    async def get(self, key, loader, ttl):
        if key in self.values:
            value, expires = self.values[key]
            if self.clock() < expires:
                return value
            self.values.pop(key, None)
        task = self._loads.get(key)
        if task is None:
            task = asyncio.create_task(self._load(key, loader, ttl))
            self._loads[key] = task
            self._tasks.add(task)
            task.add_done_callback(self._load_done)
        return await asyncio.shield(task)

    async def _load(self, key, loader, ttl):
        task = asyncio.current_task()
        try:
            value = await loader()
            if self._loads.get(key) is task and ttl > 0:
                self.values[key] = (value, self.clock() + ttl)
            return value
        finally:
            if self._loads.get(key) is task:
                self._loads.pop(key, None)

    def _load_done(self, task):
        self._tasks.discard(task)
        if not task.cancelled():
            task.exception()

    def invalidate(self, key):
        self.values.pop(key, None)
        self._loads.pop(key, None)
