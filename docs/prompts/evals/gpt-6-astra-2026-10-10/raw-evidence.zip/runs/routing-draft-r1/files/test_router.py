import copy
import unittest

from router import resolve


class ResolveTests(unittest.TestCase):
    def test_alias_priority_and_first_alias(self):
        mappings = [
            {"requestModel": " input ", "systemPromptOverride": "wrong"},
            {"alias": " input ", "requestModel": " first "},
            {"alias": "input", "requestModel": "second"},
        ]
        self.assertEqual(resolve(" \tinput\n", mappings)["model"], "first")

    def test_first_request_model_match(self):
        mappings = [
            {"requestModel": " input ", "systemPromptOverride": " first "},
            {"requestModel": "input", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" input ", mappings)["prompt"], "first")

    def test_invalid_mappings_are_skipped(self):
        for invalid in ({}, {"requestModel": ""}, {"requestModel": " \t"},
                        {"requestModel": None}):
            with self.subTest(invalid=invalid):
                mappings = [
                    dict(invalid, alias=" input ", systemPromptOverride="wrong"),
                    {"requestModel": " input ", "systemPromptOverride": "right"},
                ]
                self.assertEqual(resolve("input", mappings)["prompt"], "right")
                mappings.append({"alias": "input", "requestModel": "target"})
                self.assertEqual(resolve("input", mappings)["model"], "target")

    def test_blank_alias_does_not_prevent_request_match(self):
        for alias in ("", " \t", None):
            with self.subTest(alias=alias):
                self.assertEqual(
                    resolve("input", [{"alias": alias, "requestModel": " input ",
                                       "systemPromptOverride": "matched"}])["prompt"],
                    "matched",
                )

    def test_only_one_mapping_layer(self):
        mappings = [
            {"alias": "a", "requestModel": " b ", "systemPromptOverride": "first",
             "protocol": " chat "},
            {"alias": "b", "requestModel": "c", "systemPromptOverride": "second"},
            {"alias": "c", "requestModel": "a"},
        ]
        self.assertEqual(resolve("a", mappings),
                         {"model": "b", "prompt": "first", "protocol": "chat"})

    def test_prompt_precedence_and_whitespace(self):
        cases = [
            (" override ", " supplier ", "override"),
            (" \t\n", " supplier ", "supplier"),
            ("", " supplier ", "supplier"),
            (None, " supplier ", "supplier"),
            ("", " \t\n", " DEFAULT \n"),
            ("", None, " DEFAULT \n"),
        ]
        for override, supplier, expected in cases:
            with self.subTest(override=override, supplier=supplier):
                result = resolve(
                    "input", [{"requestModel": "input",
                               "systemPromptOverride": override}],
                    supplier_prompt=supplier, default_prompt=" DEFAULT \n",
                )
                self.assertEqual(result["prompt"], expected)

    def test_protocol_precedence_and_whitespace(self):
        for protocol, expected in ((" chat \n", "chat"), (" \t", " fallback "),
                                   ("", " fallback "), (None, " fallback ")):
            with self.subTest(protocol=protocol):
                result = resolve("input", [{"requestModel": "input",
                                           "protocol": protocol}],
                                 default_protocol=" fallback ")
                self.assertEqual(result["protocol"], expected)

    def test_unmatched_input_and_defaults(self):
        self.assertEqual(
            resolve(" unknown ", [{"requestModel": "other", "protocol": "chat",
                                   "systemPromptOverride": "ignored"}],
                    default_prompt=" DEFAULT ", default_protocol=" fallback "),
            {"model": "unknown", "prompt": " DEFAULT ", "protocol": " fallback "},
        )
        self.assertEqual(resolve("unknown", [], supplier_prompt=" supplier ")["prompt"],
                         "supplier")
        self.assertEqual(resolve("unknown", [], default_prompt="")["prompt"], "")

    def test_empty_input_raises(self):
        for name in ("", " \t\r\n", None):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_not_modified(self):
        mappings = [
            {"alias": " input ", "requestModel": " target ",
             "systemPromptOverride": " prompt ", "protocol": " chat "},
            {"alias": "target", "requestModel": " \t"},
        ]
        original = copy.deepcopy(mappings)
        for name in ("input", "target", "unknown"):
            resolve(name, mappings)
            self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
