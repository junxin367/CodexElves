def resolve(name, mappings, supplier_prompt="", default_prompt="DEFAULT", default_protocol="responses"):
    name = name.strip()
    if not name:
        raise ValueError("Model name must not be empty")

    entry = None
    for mapping in mappings:
        request_model = (mapping.get("requestModel") or "").strip()
        if not request_model:
            continue
        alias = (mapping.get("alias") or "").strip()
        if alias and alias == name:
            entry = mapping
            break
        if entry is None and request_model == name:
            entry = mapping

    if entry is None:
        entry = {}
    model = (entry.get("requestModel") or name).strip()
    prompt = ((entry.get("systemPromptOverride") or "").strip()
              or (supplier_prompt or "").strip() or default_prompt)
    protocol = (entry.get("protocol") or "").strip() or default_protocol
    return {"model": model, "prompt": prompt, "protocol": protocol}
