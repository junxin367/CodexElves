import copy
import unittest

from router import resolve


class ResolveTests(unittest.TestCase):
    def test_alias_priority_and_trimmed_names(self):
        mappings = [
            {"requestModel": " alias ", "systemPromptOverride": "wrong"},
            {"alias": " alias\t", "requestModel": " target ",
             "systemPromptOverride": " right ", "protocol": " chat "},
        ]
        self.assertEqual(resolve("\talias ", mappings), {
            "model": "target", "prompt": "right", "protocol": "chat",
        })

    def test_first_alias_match_wins(self):
        mappings = [
            {"alias": " name ", "requestModel": "first"},
            {"alias": "name", "requestModel": "second"},
        ]
        self.assertEqual(resolve("name", mappings)["model"], "first")

    def test_first_request_model_match_wins(self):
        mappings = [
            {"requestModel": " name ", "systemPromptOverride": "first"},
            {"requestModel": "name", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" name ", mappings)["prompt"], "first")

    def test_invalid_request_models_are_skipped(self):
        for invalid in ({}, {"requestModel": ""}, {"requestModel": " \t\n"},
                        {"requestModel": None}):
            with self.subTest(invalid=invalid):
                invalid = dict(invalid, alias="name", systemPromptOverride="wrong")
                for valid in (
                    {"alias": "name", "requestModel": "target"},
                    {"requestModel": "name"},
                ):
                    self.assertEqual(resolve("name", [invalid, valid])["model"],
                                     valid["requestModel"])
                self.assertEqual(resolve(" name ", [invalid]), {
                    "model": "name", "prompt": "DEFAULT", "protocol": "responses",
                })

    def test_blank_alias_allows_request_model_match(self):
        for alias in ("", " \t", None):
            with self.subTest(alias=alias):
                self.assertEqual(resolve(" name ", [
                    {"alias": alias, "requestModel": " name ",
                     "systemPromptOverride": "matched"},
                ])["prompt"], "matched")

    def test_mapping_is_not_recursive(self):
        mappings = [
            {"alias": "a", "requestModel": "b", "systemPromptOverride": "first"},
            {"alias": "b", "requestModel": "c", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve("a", mappings), {
            "model": "b", "prompt": "first", "protocol": "responses",
        })
        mappings[1]["requestModel"] = "a"
        self.assertEqual(resolve("a", mappings)["model"], "b")

    def test_prompt_fallbacks(self):
        for override, supplier, expected in (
            (" override \n", " supplier ", "override"),
            (" \t", " supplier \n", "supplier"),
            ("", " supplier ", "supplier"),
            (None, " supplier ", "supplier"),
            (" \n", "\t ", " default \n"),
            ("", "", " default \n"),
        ):
            with self.subTest(override=override, supplier=supplier):
                self.assertEqual(resolve(
                    "name", [{"requestModel": "name", "systemPromptOverride": override}],
                    supplier_prompt=supplier, default_prompt=" default \n",
                )["prompt"], expected)

    def test_protocol_fallbacks(self):
        for protocol, expected in (
            (" chat \n", "chat"),
            (" \t", " default "),
            ("", " default "),
            (None, " default "),
        ):
            with self.subTest(protocol=protocol):
                self.assertEqual(resolve(
                    "name", [{"requestModel": "name", "protocol": protocol}],
                    default_protocol=" default ",
                )["protocol"], expected)

    def test_unmatched_name_and_defaults(self):
        mappings = [{"requestModel": "other", "systemPromptOverride": "wrong",
                     "protocol": "wrong"}]
        self.assertEqual(resolve(" unknown \n", mappings,
                                 supplier_prompt=" supplier "), {
            "model": "unknown", "prompt": "supplier", "protocol": "responses",
        })
        self.assertEqual(resolve("unknown", [], supplier_prompt=" \t",
                                 default_prompt=" default ",
                                 default_protocol=" custom "), {
            "model": "unknown", "prompt": " default ", "protocol": " custom ",
        })

    def test_empty_input_raises(self):
        for name in ("", " ", "\t\r\n"):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_not_modified(self):
        mappings = [
            {"alias": " name ", "requestModel": " target ",
             "systemPromptOverride": " override ", "protocol": " chat ",
             "extra": {"items": [1, 2]}},
            {"alias": "invalid", "requestModel": " \t"},
        ]
        original = copy.deepcopy(mappings)
        for name in ("name", "target", "invalid", "unknown"):
            resolve(name, mappings)
            self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
