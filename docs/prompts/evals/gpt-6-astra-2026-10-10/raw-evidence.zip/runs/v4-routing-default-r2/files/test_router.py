import copy
import unittest

from router import resolve


class ResolveRegressionTests(unittest.TestCase):
    def test_alias_priority_and_first_alias_match(self):
        mappings = [
            {"requestModel": " input ", "systemPromptOverride": "model match"},
            {"alias": " input ", "requestModel": " target ",
             "systemPromptOverride": " first alias ", "protocol": " chat "},
            {"alias": "input", "requestModel": "other"},
        ]
        self.assertEqual(
            resolve(" \tinput\n", mappings),
            {"model": "target", "prompt": "first alias", "protocol": "chat"},
        )

    def test_first_request_model_match(self):
        mappings = [
            {"requestModel": " target ", "alias": " \t ",
             "systemPromptOverride": " first "},
            {"requestModel": "target", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" target ", mappings)["prompt"], "first")

    def test_invalid_request_models_are_ignored(self):
        mappings = [
            {"alias": "input", "systemPromptOverride": "missing"},
            {"alias": "input", "requestModel": None},
            {"alias": "input", "requestModel": ""},
            {"alias": "input", "requestModel": " \t\n"},
        ]
        self.assertEqual(
            resolve(" input ", mappings),
            {"model": "input", "prompt": "DEFAULT", "protocol": "responses"},
        )
        mappings.append({"requestModel": " input ", "systemPromptOverride": "valid"})
        self.assertEqual(resolve("input", mappings)["prompt"], "valid")

    def test_mapping_is_resolved_only_once(self):
        mappings = [
            {"alias": "a", "requestModel": " b ", "systemPromptOverride": "one"},
            {"alias": "b", "requestModel": "c", "systemPromptOverride": "two"},
        ]
        self.assertEqual(resolve("a", mappings)["model"], "b")
        self.assertEqual(resolve("a", mappings)["prompt"], "one")
        self.assertEqual(
            resolve("a", [{"alias": "a", "requestModel": "a"}])["model"], "a"
        )

    def test_prompt_fallbacks(self):
        cases = [
            (" override ", " supplier ", "override"),
            (" \t\n", " supplier ", "supplier"),
            ("", "", " DEFAULT \n"),
            (None, " \t ", " DEFAULT \n"),
        ]
        for override, supplier, expected in cases:
            with self.subTest(override=override, supplier=supplier):
                self.assertEqual(
                    resolve(
                        "model",
                        [{"requestModel": "model", "systemPromptOverride": override}],
                        supplier_prompt=supplier,
                        default_prompt=" DEFAULT \n",
                    )["prompt"],
                    expected,
                )
        self.assertEqual(resolve("model", [], default_prompt="")["prompt"], "")

    def test_protocol_fallbacks_preserve_default(self):
        for protocol in ("", " \t\n", None):
            with self.subTest(protocol=protocol):
                self.assertEqual(
                    resolve(
                        "model",
                        [{"requestModel": "model", "protocol": protocol}],
                        default_protocol=" default ",
                    )["protocol"],
                    " default ",
                )

    def test_unmatched_name_and_defaults(self):
        self.assertEqual(
            resolve(" unknown ", [], supplier_prompt=" supplier ",
                    default_protocol=" custom "),
            {"model": "unknown", "prompt": "supplier", "protocol": " custom "},
        )

    def test_blank_input_raises(self):
        for name in ("", " ", "\t\n"):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_not_modified(self):
        mappings = [
            {"alias": " input ", "requestModel": " target ",
             "systemPromptOverride": " prompt ", "protocol": " chat "},
            {"alias": "invalid", "requestModel": " "},
        ]
        original = copy.deepcopy(mappings)
        for name in (" input ", " target ", "unknown"):
            resolve(name, mappings)
            self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
