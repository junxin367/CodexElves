import unittest

from decoder import Decoder


class DecoderTests(unittest.TestCase):
    def assert_stream(self, text, expected):
        payload = text.encode("utf-8")
        chunks = [[payload], [bytes([byte]) for byte in payload]]
        chunks.extend(
            [payload[:index], b"", payload[index:]]
            for index in range(len(payload) + 1)
        )
        for parts in chunks:
            with self.subTest(parts=parts):
                decoder = Decoder()
                events = []
                for part in parts:
                    events.extend(decoder.feed(part))
                events.extend(decoder.finish())
                self.assertEqual(events, expected)
                self.assertEqual(decoder.finish(), [])

    def test_utf8_and_line_endings(self):
        for ending in ("\n", "\r\n", "\r"):
            with self.subTest(ending=ending):
                self.assert_stream(
                    f"data: 中文😀{ending}data: café{ending}{ending}",
                    [{"event": "message", "data": "中文😀\ncafé", "id": ""}],
                )

    def test_mixed_line_endings(self):
        self.assert_stream(
            "data: a\r\ndata: b\rdata: c\n\rdata: d\r\n\r\n",
            [
                {"event": "message", "data": "a\nb\nc", "id": ""},
                {"event": "message", "data": "d", "id": ""},
            ],
        )

    def test_feed_dispatch_timing(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"data: first\r"), [])
        self.assertEqual(decoder.feed(b""), [])
        self.assertEqual(
            decoder.feed(b"\n\r"),
            [{"event": "message", "data": "first", "id": ""}],
        )
        self.assertEqual(decoder.feed(b"\n"), [])
        self.assertEqual(decoder.feed(b"data: second"), [])
        self.assertEqual(
            decoder.feed(b"\n\n"),
            [{"event": "message", "data": "second", "id": ""}],
        )
        self.assertEqual(decoder.finish(), [])

    def test_empty_data_and_no_colon(self):
        self.assert_stream(
            "data\n\n" "data:\ndata: \ndata\n\n",
            [
                {"event": "message", "data": "", "id": ""},
                {"event": "message", "data": "\n\n", "id": ""},
            ],
        )

    def test_field_values_preserve_whitespace(self):
        self.assert_stream(
            " data: ignored\nData: ignored\n"
            "id:  key \t\n"
            "event:  kind \t\n"
            "data:  value: rest \t\n"
            "data:\tvalue \t\n"
            "data:\u00a0value\u00a0\n\n",
            [{
                "event": " kind \t",
                "data": " value: rest \t\n\tvalue \t\n\u00a0value\u00a0",
                "id": " key \t",
            }],
        )

    def test_comments_unknown_fields_and_no_data(self):
        self.assert_stream(
            ": data: ignored\nunknown: data: ignored\nretry: 100\n\n"
            "event: ignored\n\n\n",
            [],
        )

    def test_event_defaults_and_resets(self):
        self.assert_stream(
            "event: discarded\n\n"
            "data: a\n\n"
            "event: old\nevent: custom\ndata: b\n\n"
            "data: c\n\n"
            "event: old\nevent:\ndata: d\n\n"
            "event: old\nevent\ndata: e\n\n",
            [
                {"event": "message", "data": "a", "id": ""},
                {"event": "custom", "data": "b", "id": ""},
                {"event": "message", "data": "c", "id": ""},
                {"event": "message", "data": "d", "id": ""},
                {"event": "message", "data": "e", "id": ""},
            ],
        )

    def test_id_persistence_clearing_and_nul(self):
        self.assert_stream(
            "id: saved\n\n"
            "data: a\n\n"
            "id: bad\0id\n\n"
            "data: b\n\n"
            "id:\n\n"
            "data: c\n\n"
            "data: d\nid: next\n\n"
            "id\n\n"
            "data: e\n\n",
            [
                {"event": "message", "data": "a", "id": "saved"},
                {"event": "message", "data": "b", "id": "saved"},
                {"event": "message", "data": "c", "id": ""},
                {"event": "message", "data": "d", "id": "next"},
                {"event": "message", "data": "e", "id": ""},
            ],
        )

    def test_id_only_feed_updates_later_event(self):
        decoder = Decoder()
        self.assertEqual(decoder.feed(b"id: saved\n\n"), [])
        self.assertEqual(
            decoder.feed(b"data: value\n\n"),
            [{"event": "message", "data": "value", "id": "saved"}],
        )

    def test_only_one_initial_bom_is_ignored(self):
        self.assert_stream(
            "\ufeffdata: first\n\n"
            "\ufeffdata: ignored\n"
            "data: \ufeffkept\n\n",
            [
                {"event": "message", "data": "first", "id": ""},
                {"event": "message", "data": "\ufeffkept", "id": ""},
            ],
        )
        self.assert_stream("\ufeff\ufeffdata: ignored\n\n", [])
        self.assert_stream("\n\ufeffdata: ignored\n\n", [])

    def test_finish_unterminated_data(self):
        for tail in ("", "\n", "\r", "\r\n"):
            with self.subTest(tail=tail):
                self.assert_stream(
                    "data: value" + tail,
                    [{"event": "message", "data": "value", "id": ""}],
                )
        self.assert_stream(
            "data",
            [{"event": "message", "data": "", "id": ""}],
        )

    def test_finish_processes_last_field(self):
        self.assert_stream(
            "data: value\nevent: custom",
            [{"event": "custom", "data": "value", "id": ""}],
        )
        self.assert_stream(
            "data: value\nid: final",
            [{"event": "message", "data": "value", "id": "final"}],
        )
        self.assert_stream("id: final", [])
        self.assert_stream("event: custom", [])
        self.assert_stream(": comment", [])

    def test_non_line_break_characters_are_preserved(self):
        self.assert_stream(
            "data: a\v\f\u0085\u2028\u2029\0b\n\n",
            [{"event": "message", "data": "a\v\f\u0085\u2028\u2029\0b", "id": ""}],
        )

    def test_empty_stream_and_finish_lifecycle(self):
        for text in ("", "\ufeff", "\n\r\n\r"):
            self.assert_stream(text, [])
        decoder = Decoder()
        self.assertEqual(decoder.finish(), [])
        self.assertEqual(decoder.finish(), [])
        for chunk in (b"", b"data: late\n\n"):
            with self.assertRaises(ValueError):
                decoder.feed(chunk)


if __name__ == "__main__":
    unittest.main()
