import asyncio
import unittest

from cache import Cache


class CacheTests(unittest.IsolatedAsyncioTestCase):
    def setUp(self):
        self.now = 0
        self.cache = Cache(lambda: self.now)

    async def start_get(self, loader, ttl=10, key="k"):
        entered = asyncio.Event()

        async def get():
            entered.set()
            return await self.cache.get(key, loader, ttl)

        task = asyncio.create_task(get())
        await entered.wait()
        return task

    async def unexpected_loader(self):
        self.fail("unexpected loader invocation")

    async def test_ttl_starts_at_completion_and_expires_at_boundary(self):
        started = asyncio.Event()
        release = asyncio.Event()
        calls = 0

        async def loader():
            nonlocal calls
            calls += 1
            started.set()
            await release.wait()
            return calls

        task = await self.start_get(loader)
        await started.wait()
        self.now = 100
        release.set()
        self.assertEqual(await task, 1)
        self.now = 109
        self.assertEqual(await self.cache.get("k", self.unexpected_loader, 1), 1)
        self.now = 110
        self.assertEqual(await self.cache.get("k", loader, 10), 2)

    async def test_shared_result_uses_first_loader_and_ttl(self):
        release = asyncio.Event()
        value = object()
        calls = 0

        async def loader():
            nonlocal calls
            calls += 1
            await release.wait()
            return value

        first = await self.start_get(loader, 5)
        others = [
            await self.start_get(self.unexpected_loader, 100)
            for _ in range(5)
        ]
        release.set()
        results = await asyncio.gather(first, *others)
        self.assertTrue(all(result is value for result in results))
        self.assertEqual(calls, 1)
        self.now = 5
        self.assertIs(await self.cache.get("k", loader, 5), value)
        self.assertEqual(calls, 2)

    async def test_nonpositive_ttl_shares_only_inflight_result(self):
        for ttl in (0, -10):
            with self.subTest(ttl=ttl):
                release = asyncio.Event()
                calls = 0

                async def loader():
                    nonlocal calls
                    calls += 1
                    await release.wait()
                    return calls

                first = await self.start_get(loader, ttl)
                second = await self.start_get(self.unexpected_loader, 100)
                release.set()
                self.assertEqual(await asyncio.gather(first, second), [1, 1])
                self.assertNotIn("k", self.cache.values)
                self.assertEqual(await self.cache.get("k", loader, ttl), 2)

    async def test_shared_failure_and_retry(self):
        release = asyncio.Event()
        error = ValueError("load failed")
        calls = 0

        async def loader():
            nonlocal calls
            calls += 1
            await release.wait()
            if calls == 1:
                raise error
            return "retry"

        first = await self.start_get(loader)
        second = await self.start_get(self.unexpected_loader)
        release.set()
        results = await asyncio.gather(first, second, return_exceptions=True)
        self.assertTrue(all(result is error for result in results))
        self.assertEqual(calls, 1)
        self.assertEqual(await self.cache.get("k", loader, 10), "retry")
        self.assertEqual(calls, 2)

    async def test_cancelling_either_waiter_does_not_cancel_loader(self):
        for cancelled_index in (0, 1):
            with self.subTest(cancelled_index=cancelled_index):
                self.cache.invalidate("k")
                release = asyncio.Event()

                async def loader():
                    await release.wait()
                    return "value"

                tasks = [
                    await self.start_get(loader),
                    await self.start_get(self.unexpected_loader),
                ]
                tasks[cancelled_index].cancel()
                with self.assertRaises(asyncio.CancelledError):
                    await tasks[cancelled_index]
                third = await self.start_get(self.unexpected_loader)
                release.set()
                self.assertEqual(await tasks[1 - cancelled_index], "value")
                self.assertEqual(await third, "value")
                self.assertEqual(
                    await self.cache.get("k", self.unexpected_loader, 10),
                    "value",
                )

    async def test_abandoned_load_finishes_without_unhandled_exception(self):
        loop = asyncio.get_running_loop()
        previous_handler = loop.get_exception_handler()
        errors = []
        loop.set_exception_handler(lambda loop, context: errors.append(context))
        try:
            for fail in (False, True):
                with self.subTest(fail=fail):
                    self.cache.invalidate("k")
                    release = asyncio.Event()

                    async def loader():
                        await release.wait()
                        if fail:
                            raise ValueError("abandoned")
                        return "value"

                    waiter = await self.start_get(loader)
                    waiter.cancel()
                    with self.assertRaises(asyncio.CancelledError):
                        await waiter
                    workers = tuple(self.cache._tasks)
                    self.assertTrue(workers)
                    release.set()
                    await asyncio.gather(*workers)
                    if fail:
                        self.assertNotIn("k", self.cache.values)
                    else:
                        self.assertEqual(
                            await self.cache.get("k", self.unexpected_loader, 10),
                            "value",
                        )
            self.assertEqual(errors, [])
        finally:
            loop.set_exception_handler(previous_handler)

    async def test_invalidation_isolates_generations(self):
        for old_fails in (False, True):
            for old_finishes_first in (False, True):
                with self.subTest(
                    old_fails=old_fails,
                    old_finishes_first=old_finishes_first,
                ):
                    self.cache.invalidate("k")
                    old_release = asyncio.Event()
                    new_release = asyncio.Event()
                    old_error = ValueError("old failure")
                    new_started = asyncio.Event()

                    async def old_loader():
                        await old_release.wait()
                        if old_fails:
                            raise old_error
                        return "old"

                    async def new_loader():
                        new_started.set()
                        await new_release.wait()
                        return "new"

                    old = await self.start_get(old_loader)
                    old_peer = await self.start_get(self.unexpected_loader)
                    self.cache.invalidate("k")
                    new = await self.start_get(new_loader)
                    await new_started.wait()
                    if not old_finishes_first:
                        new_release.set()
                        self.assertEqual(await new, "new")
                    old_release.set()
                    results = await asyncio.gather(
                        old, old_peer, return_exceptions=True
                    )
                    if old_fails:
                        self.assertTrue(all(result is old_error for result in results))
                    else:
                        self.assertEqual(results, ["old", "old"])
                    if old_finishes_first:
                        peer = await self.start_get(self.unexpected_loader)
                        self.assertFalse(peer.done())
                        new_release.set()
                        self.assertEqual(await asyncio.gather(new, peer), ["new", "new"])
                    self.assertEqual(
                        await self.cache.get("k", self.unexpected_loader, 10),
                        "new",
                    )

    async def test_invalidate_cached_value_and_missing_key(self):
        self.cache.invalidate("missing")
        calls = 0

        async def loader():
            nonlocal calls
            calls += 1
            return calls

        self.assertEqual(await self.cache.get("k", loader, 10), 1)
        self.cache.invalidate("k")
        self.assertEqual(await self.cache.get("k", loader, 10), 2)

    async def test_different_keys_load_independently(self):
        release = asyncio.Event()

        async def slow():
            await release.wait()
            return "slow"

        async def fast():
            return "fast"

        first = await self.start_get(slow, key="first")
        self.assertEqual(await self.cache.get("second", fast, 10), "fast")
        self.assertFalse(first.done())
        release.set()
        self.assertEqual(await first, "slow")

    async def test_loader_cancellation_allows_retry(self):
        release = asyncio.Event()

        async def loader():
            await release.wait()
            raise asyncio.CancelledError()

        first = await self.start_get(loader)
        second = await self.start_get(self.unexpected_loader)
        release.set()
        results = await asyncio.gather(first, second, return_exceptions=True)
        self.assertTrue(all(isinstance(result, asyncio.CancelledError) for result in results))

        async def retry():
            return "retry"

        self.assertEqual(await self.cache.get("k", retry, 10), "retry")

    async def test_eager_task_factory(self):
        loop = asyncio.get_running_loop()
        previous_factory = loop.get_task_factory()
        loop.set_task_factory(asyncio.eager_task_factory)
        try:
            calls = 0

            async def loader():
                nonlocal calls
                calls += 1
                return calls

            self.assertEqual(await self.cache.get("k", loader, 0), 1)
            self.assertEqual(await self.cache.get("k", loader, 0), 2)
            self.assertEqual(await self.cache.get("k", loader, 10), 3)
            self.assertEqual(await self.cache.get("k", loader, 10), 3)
        finally:
            loop.set_task_factory(previous_factory)


if __name__ == "__main__":
    unittest.main()
