import asyncio


class Cache:
    def __init__(self, clock):
        self.clock = clock
        self.values = {}
        self._pending = {}
        self._tasks = set()

    async def get(self, key, loader, ttl):
        if key in self.values:
            value, expires = self.values[key]
            if self.clock() < expires:
                return value
            self.values.pop(key)
        future = self._pending.get(key)
        if future is None:
            future = asyncio.get_running_loop().create_future()
            self._pending[key] = future
            task = asyncio.create_task(self._load(key, loader, ttl, future))
            self._tasks.add(task)
            task.add_done_callback(self._tasks.discard)
        return await asyncio.shield(future)

    async def _load(self, key, loader, ttl, future):
        try:
            value = await loader()
            if ttl > 0 and self._pending.get(key) is future:
                self.values[key] = (value, self.clock() + ttl)
            future.set_result(value)
        except asyncio.CancelledError:
            future.cancel()
        except Exception as error:
            future.set_exception(error)
            # A load can fail after all of its waiters have been cancelled.
            future.exception()
        finally:
            if self._pending.get(key) is future:
                self._pending.pop(key)

    def invalidate(self, key):
        self.values.pop(key, None)
        self._pending.pop(key, None)
