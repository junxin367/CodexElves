import copy
import unittest

from router import resolve


class ResolveTests(unittest.TestCase):
    def test_alias_priority_and_normalization(self):
        mappings = [
            {"requestModel": " name ", "systemPromptOverride": "wrong"},
            {
                "alias": "\tname ",
                "requestModel": " target\n",
                "systemPromptOverride": " right ",
                "protocol": " chat ",
            },
        ]
        self.assertEqual(
            resolve(" name\n", mappings),
            {"model": "target", "prompt": "right", "protocol": "chat"},
        )

    def test_first_alias_match_wins(self):
        mappings = [
            {"alias": "name", "requestModel": " first "},
            {"alias": " name ", "requestModel": "second"},
        ]
        self.assertEqual(resolve("name", mappings)["model"], "first")

    def test_first_request_model_match_wins(self):
        mappings = [
            {"requestModel": " name ", "systemPromptOverride": "first"},
            {"requestModel": "name", "systemPromptOverride": "second"},
        ]
        self.assertEqual(resolve(" name ", mappings)["prompt"], "first")

    def test_invalid_mappings_are_skipped(self):
        invalid = [
            {"alias": "name", "systemPromptOverride": "wrong"},
            {"alias": "name", "requestModel": ""},
            {"alias": "name", "requestModel": " \t\n"},
            {"alias": "name", "requestModel": None},
        ]
        for valid in (
            {"alias": "name", "requestModel": "target"},
            {"requestModel": "name", "systemPromptOverride": "right"},
        ):
            with self.subTest(valid=valid):
                self.assertEqual(
                    resolve("name", invalid + [valid]), resolve("name", [valid])
                )
        self.assertEqual(
            resolve(" name ", invalid),
            {"model": "name", "prompt": "DEFAULT", "protocol": "responses"},
        )

    def test_blank_alias_does_not_prevent_request_model_match(self):
        for alias in ("", " \t", None):
            with self.subTest(alias=alias):
                self.assertEqual(
                    resolve("name", [
                        {"alias": alias, "requestModel": " name ", "protocol": "chat"}
                    ])["protocol"],
                    "chat",
                )

    def test_mapping_is_not_recursive(self):
        mappings = [
            {"alias": "a", "requestModel": "b", "systemPromptOverride": "first"},
            {"alias": "b", "requestModel": "c", "systemPromptOverride": "second"},
        ]
        self.assertEqual(
            resolve("a", mappings),
            {"model": "b", "prompt": "first", "protocol": "responses"},
        )
        mappings[1]["requestModel"] = "a"
        self.assertEqual(resolve("a", mappings)["model"], "b")

    def test_prompt_fallbacks(self):
        for override, supplier, expected in (
            (" override ", " supplier ", "override"),
            (" \t\n", " supplier\n", "supplier"),
            ("", "\t ", " default \n"),
            (None, None, " default \n"),
        ):
            with self.subTest(override=override, supplier=supplier):
                self.assertEqual(
                    resolve(
                        "name",
                        [{"requestModel": "name", "systemPromptOverride": override}],
                        supplier_prompt=supplier,
                        default_prompt=" default \n",
                    )["prompt"],
                    expected,
                )

    def test_protocol_fallbacks(self):
        for protocol, expected in (
            (" chat\n", "chat"),
            (" \t\n", " default "),
            ("", " default "),
            (None, " default "),
        ):
            with self.subTest(protocol=protocol):
                self.assertEqual(
                    resolve(
                        "name",
                        [{"requestModel": "name", "protocol": protocol}],
                        default_protocol=" default ",
                    )["protocol"],
                    expected,
                )

    def test_unmatched_model_and_defaults(self):
        mappings = [
            {"requestModel": "other", "systemPromptOverride": "wrong", "protocol": "chat"}
        ]
        self.assertEqual(
            resolve(" unknown\n", mappings, supplier_prompt=" supplier "),
            {"model": "unknown", "prompt": "supplier", "protocol": "responses"},
        )
        self.assertEqual(
            resolve("unknown", [], default_prompt=" default ", default_protocol=" chat "),
            {"model": "unknown", "prompt": " default ", "protocol": " chat "},
        )

    def test_blank_input_raises(self):
        for name in ("", " ", "\t\r\n"):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):
                    resolve(name, [{"alias": "", "requestModel": "target"}])

    def test_mappings_are_not_modified(self):
        mappings = [
            {"alias": " name ", "requestModel": " \t"},
            {
                "alias": " name ",
                "requestModel": " target ",
                "systemPromptOverride": " prompt ",
                "protocol": " chat ",
            },
            {"requestModel": " direct "},
        ]
        original = copy.deepcopy(mappings)
        for name in ("name", "direct", "unknown"):
            resolve(name, mappings)
            self.assertEqual(mappings, original)


if __name__ == "__main__":
    unittest.main()
